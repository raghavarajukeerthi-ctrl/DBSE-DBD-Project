import { useState, useEffect, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Shield, Smartphone, CreditCard, Building2, CheckCircle, Loader2, Eye, EyeOff } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";

type PayMethod = "upi" | "netbanking" | "card";
type Step = "select" | "pending" | "success";

const BANKS = [
  "State Bank of India", "HDFC Bank", "ICICI Bank", "Axis Bank",
  "Kotak Mahindra Bank", "Punjab National Bank", "Bank of Baroda", "Canara Bank",
];

const UPI_APPS = [
  { name: "Google Pay", icon: "🟢" },
  { name: "PhonePe", icon: "🟣" },
  { name: "Paytm", icon: "🔵" },
  { name: "BHIM", icon: "🟠" },
];

function UPIQRPanel({ fare, onPaid }: { fare: number; onPaid: () => void }) {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const qrValue = `upi://pay?pa=goveya@upi&pn=GoVeya&am=${fare}&cu=INR&tn=GoVeya+Booking`;

  useEffect(() => {
    // Silently trigger payment after 30 seconds — nothing shown to user
    timerRef.current = setTimeout(onPaid, 30000);
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [onPaid]);

  return (
    <div className="flex flex-col items-center gap-5 py-2">
      {/* Real scannable QR */}
      <div className="bg-white p-4 rounded-2xl shadow-lg shadow-[#4f6ef7]/10">
        <QRCodeSVG
          value={qrValue}
          size={200}
          bgColor="#ffffff"
          fgColor="#06080f"
          level="H"
          marginSize={1}
        />
      </div>

      {/* UPI details */}
      <div className="text-center">
        <div className="font-mono text-sm font-bold text-[#4f6ef7]">goveya@upi</div>
        <div className="text-xs text-[var(--muted-foreground)] mt-1">
          Amount: <span className="font-mono font-bold text-[var(--foreground)]">₹{fare.toLocaleString()}</span>
        </div>
      </div>

      {/* Supported apps */}
      <div className="flex gap-3 text-xs text-[var(--muted-foreground)]">
        <span>🟢 GPay</span><span>🟣 PhonePe</span><span>🔵 Paytm</span><span>🟠 BHIM</span>
      </div>

      <div className="text-xs text-[var(--muted-foreground)] text-center px-4">
        Scan with any UPI app. QR expires in 30 seconds.
      </div>
    </div>
  );
}

export default function Payment() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const fare = Number(params.get("fare") || 2499);
  const mode = params.get("mode") || "flight";
  const seats = params.get("seats") || "12A";
  const name = params.get("name") || "Passenger";
  const passengersRaw = params.get("passengers") || "";

  const [method, setMethod] = useState<PayMethod>("upi");
  const [upiId, setUpiId] = useState("");
  const [upiSubMethod, setUpiSubMethod] = useState<"id" | "qr">("id");
  const [selectedBank, setSelectedBank] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [showCvv, setShowCvv] = useState(false);
  const [step, setStep] = useState<Step>("select");

  const bookingId = `GVY-${Date.now().toString().slice(-6)}`;
  const taxes = Math.round(fare * 0.15);
  const base = fare - taxes;

  const formatCard = (val: string) => val.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  const formatExpiry = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 4);
    return digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits;
  };

  const handlePay = () => {
    setStep("pending");
    setTimeout(() => setStep("success"), 3000);
  };

  if (step === "pending") {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="glass rounded-3xl border border-[var(--border)] p-12 text-center max-w-sm w-full">
          <div className="w-16 h-16 rounded-full bg-[#4f6ef7]/20 flex items-center justify-center mx-auto mb-5">
            <Loader2 size={32} className="text-[#4f6ef7] animate-spin" />
          </div>
          <h2 className="font-display font-bold text-xl mb-2">Processing Payment</h2>
          <p className="text-[var(--muted-foreground)] text-sm">Please don't close this window.</p>
        </div>
      </div>
    );
  }


  const SuccessModal = step === "success" ? (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(10px)" }}>
      <div className="glass rounded-3xl border border-[#00d4aa]/40 p-10 text-center max-w-sm w-full"
        style={{ animation: "fadeInUp 0.4s ease forwards" }}>
        {/* Animated checkmark */}
        <div className="relative w-20 h-20 mx-auto mb-6">
          <div className="absolute inset-0 rounded-full bg-[#00d4aa]/20 animate-ping" />
          <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-[#00d4aa] to-[#4f6ef7] flex items-center justify-center">
            <CheckCircle size={36} className="text-white" />
          </div>
        </div>
        <h2 className="font-display font-black text-2xl mb-1 text-[#00d4aa]">Payment Successful!</h2>
        <p className="text-[var(--muted-foreground)] text-sm mb-5">Your booking is confirmed 🎉</p>
        <div className="bg-[var(--muted)] rounded-2xl p-4 text-sm mb-6 text-left flex flex-col gap-2">
          <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Booking ID</span><span className="font-mono font-bold text-[#4f6ef7]">{bookingId}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Passenger</span><span className="font-medium">{name || "Passenger"}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Amount Paid</span><span className="font-mono text-[#00d4aa] font-bold">₹{fare.toLocaleString()}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Method</span><span className="font-medium">UPI</span></div>
        </div>
        <button
          onClick={() => navigate(`/ticket?bookingId=${bookingId}&mode=${mode}&seats=${encodeURIComponent(seats)}&name=${encodeURIComponent(name)}&fare=${fare}&passengers=${encodeURIComponent(passengersRaw)}`)}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-[#4f6ef7] to-[#00d4aa] text-white font-bold text-sm hover:opacity-90 mb-3"
        >
          View & Download Ticket →
        </button>
        <button onClick={() => navigate("/")} className="w-full py-2.5 rounded-xl glass border border-[var(--border)] text-sm font-medium text-[var(--muted-foreground)]">
          Back to Home
        </button>
      </div>
    </div>
  ) : null;

  const METHODS = [
    { id: "upi" as PayMethod, icon: <Smartphone size={18} />, label: "UPI", desc: "GPay, PhonePe, Paytm, BHIM" },
    { id: "netbanking" as PayMethod, icon: <Building2 size={18} />, label: "Net Banking", desc: "All major Indian banks" },
    { id: "card" as PayMethod, icon: <CreditCard size={18} />, label: "Credit / Debit Card", desc: "Visa, Mastercard, RuPay" },
  ];

  return (
    <div className="min-h-screen py-10 px-4">
      {SuccessModal}
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="font-display font-black text-3xl mb-1">Payment</h1>
          <p className="text-[var(--muted-foreground)] text-sm">Complete your booking securely</p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left: Payment form */}
          <div className="flex-1 flex flex-col gap-4">

            {/* Method selector tabs */}
            <div className="glass rounded-2xl border border-[var(--border)] p-2 flex gap-2">
              {METHODS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMethod(m.id)}
                  className={`flex-1 flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl text-xs font-semibold transition-all ${method === m.id ? "bg-[#4f6ef7] text-white" : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]"}`}
                >
                  {m.icon}
                  <span>{m.label}</span>
                </button>
              ))}
            </div>

            {/* UPI */}
            {method === "upi" && (
              <div className="glass rounded-2xl border border-[var(--border)] p-6 flex flex-col gap-4">
                <div className="flex gap-2">
                  <button onClick={() => setUpiSubMethod("id")}
                    className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-all ${upiSubMethod === "id" ? "bg-[#4f6ef7]/10 border-[#4f6ef7] text-[#4f6ef7]" : "border-[var(--border)] text-[var(--muted-foreground)]"}`}>
                    UPI ID
                  </button>
                  <button onClick={() => setUpiSubMethod("qr")}
                    className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-all ${upiSubMethod === "qr" ? "bg-[#4f6ef7]/10 border-[#4f6ef7] text-[#4f6ef7]" : "border-[var(--border)] text-[var(--muted-foreground)]"}`}>
                    QR Code
                  </button>
                </div>

                {upiSubMethod === "id" ? (
                  <div>
                    <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Enter UPI ID</label>
                    <input value={upiId} onChange={(e) => setUpiId(e.target.value)} placeholder="yourname@bank"
                      className="mt-2 w-full px-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
                    <div className="flex flex-wrap gap-2 mt-3">
                      {UPI_APPS.map((app) => (
                        <button key={app.name} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[var(--muted)] border border-[var(--border)] text-xs hover:border-[#4f6ef7] transition-all">
                          <span>{app.icon}</span> {app.name}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <UPIQRPanel key="upi-qr" fare={fare} onPaid={handlePay} />
                )}
              </div>
            )}

            {/* Net Banking */}
            {method === "netbanking" && (
              <div className="glass rounded-2xl border border-[var(--border)] p-6 flex flex-col gap-4">
                <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Select Your Bank</label>
                <div className="grid grid-cols-2 gap-2">
                  {BANKS.map((bank) => (
                    <button key={bank} onClick={() => setSelectedBank(bank)}
                      className={`px-3 py-3 rounded-xl text-xs font-medium border text-left transition-all ${selectedBank === bank ? "bg-[#4f6ef7]/10 border-[#4f6ef7] text-[#4f6ef7]" : "border-[var(--border)] text-[var(--muted-foreground)] hover:border-[#4f6ef7]/50"}`}>
                      🏦 {bank}
                    </button>
                  ))}
                </div>
                {selectedBank && (
                  <div className="p-3 rounded-xl bg-[#4f6ef7]/10 border border-[#4f6ef7]/30 text-xs text-[#4f6ef7] font-medium">
                    You'll be redirected to {selectedBank}'s secure portal to complete payment.
                  </div>
                )}
              </div>
            )}

            {/* Card */}
            {method === "card" && (
              <div className="glass rounded-2xl border border-[var(--border)] p-6 flex flex-col gap-4">
                {/* Card preview */}
                <div className="w-full h-40 rounded-2xl p-5 flex flex-col justify-between relative overflow-hidden"
                  style={{ background: "linear-gradient(135deg, #1a1f3a 0%, #4f6ef7 50%, #00d4aa 100%)" }}>
                  <div className="flex justify-between items-start">
                    <div className="w-8 h-6 rounded bg-amber-400/80" />
                    <span className="text-white/70 text-xs font-mono">GoVeya Pay</span>
                  </div>
                  <div>
                    <div className="font-mono text-white text-base tracking-widest mb-2">
                      {cardNumber || "•••• •••• •••• ••••"}
                    </div>
                    <div className="flex justify-between text-white/70 text-xs">
                      <span>{cardName || "CARD HOLDER NAME"}</span>
                      <span>{cardExpiry || "MM/YY"}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <div>
                    <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Card Number</label>
                    <input value={cardNumber} onChange={(e) => setCardNumber(formatCard(e.target.value))}
                      placeholder="1234 5678 9012 3456" maxLength={19}
                      className="mt-1 w-full px-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm font-mono focus:outline-none focus:border-[#4f6ef7]" />
                  </div>
                  <div>
                    <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Cardholder Name</label>
                    <input value={cardName} onChange={(e) => setCardName(e.target.value.toUpperCase())}
                      placeholder="AS ON CARD"
                      className="mt-1 w-full px-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Expiry</label>
                      <input value={cardExpiry} onChange={(e) => setCardExpiry(formatExpiry(e.target.value))}
                        placeholder="MM/YY" maxLength={5}
                        className="mt-1 w-full px-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm font-mono focus:outline-none focus:border-[#4f6ef7]" />
                    </div>
                    <div>
                      <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">CVV</label>
                      <div className="relative mt-1">
                        <input value={cardCvv} onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, "").slice(0, 4))}
                          type={showCvv ? "text" : "password"} placeholder="•••"
                          className="w-full px-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm font-mono focus:outline-none focus:border-[#4f6ef7]" />
                        <button onClick={() => setShowCvv(!showCvv)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]">
                          {showCvv ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 p-3 rounded-xl bg-[#00d4aa]/10 text-xs text-[#00d4aa]">
                  <Shield size={12} /> Your card details are encrypted and never stored.
                </div>
              </div>
            )}

            {/* Pay button — hidden for UPI QR (auto-pays) */}
            {!(method === "upi" && upiSubMethod === "qr") && (
              <button onClick={handlePay}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-[#4f6ef7] to-[#3b5bdb] text-white font-bold text-base hover:opacity-90 flex items-center justify-center gap-2">
                <Shield size={18} />
                Pay ₹{fare.toLocaleString()} Securely
              </button>
            )}
          </div>

          {/* Right: Summary */}
          <div className="lg:w-72 shrink-0">
            <div className="glass rounded-2xl border border-[var(--border)] p-6 sticky top-24">
              <h3 className="font-display font-bold text-base mb-4">Booking Summary</h3>
              <div className="flex flex-col gap-3 text-sm">
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Route</span><span className="font-medium">HYD → BLR</span></div>
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Transport</span><span className="font-medium capitalize">{mode}</span></div>
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Seat(s)</span><span className="font-mono text-[#4f6ef7]">{seats}</span></div>
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Passenger</span><span className="font-medium">{name || "Passenger"}</span></div>
                <div className="border-t border-[var(--border)] pt-3 flex flex-col gap-2">
                  <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Base fare</span><span className="font-mono">₹{base.toLocaleString()}</span></div>
                  <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Taxes & fees</span><span className="font-mono">₹{taxes.toLocaleString()}</span></div>
                  <div className="flex justify-between font-bold text-base border-t border-[var(--border)] pt-2 mt-1">
                    <span>Total</span><span className="font-mono text-[#00d4aa]">₹{fare.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-4 p-3 rounded-xl bg-[#00d4aa]/10 text-xs text-[#00d4aa]">
                <Shield size={12} /> Secured by GoVeya Payment Shield
              </div>
              <div className="flex items-center justify-center gap-3 mt-4 opacity-50">
                {["VISA", "MC", "RuPay", "UPI"].map((b) => (
                  <span key={b} className="text-[10px] font-mono font-bold border border-[var(--border)] px-1.5 py-0.5 rounded">{b}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
