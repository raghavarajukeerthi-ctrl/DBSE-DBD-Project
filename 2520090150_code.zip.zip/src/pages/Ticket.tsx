import { useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";
import { Download, CheckCircle, X, User } from "lucide-react";

interface Passenger {
  name: string;
  age: string;
  gender: string;
  phone: string;
  email: string;
}

function QRModal({ url, onClose }: { url: string; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center px-4"
      style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(8px)" }}
      onClick={onClose}
    >
      <div
        className="glass rounded-3xl border border-[var(--border)] p-8 flex flex-col items-center gap-5 max-w-xs w-full"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between w-full">
          <h3 className="font-display font-bold text-base">Scan to verify ticket</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full glass flex items-center justify-center hover:text-red-400">
            <X size={16} />
          </button>
        </div>

        <div className="bg-white rounded-2xl p-4">
          <QRCodeSVG
            value={url}
            size={220}
            bgColor="#ffffff"
            fgColor="#06080f"
            level="H"
          />
        </div>

        <div className="text-center">
          <p className="text-xs text-[var(--muted-foreground)]">Scan with any camera app to view and verify this ticket.</p>
        </div>

        <div className="w-full bg-[var(--muted)] rounded-xl p-3 text-center">
          <p className="font-mono text-[10px] text-[#4f6ef7] break-all">{url}</p>
        </div>
      </div>
    </div>
  );
}

export default function Ticket() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [showQR, setShowQR] = useState(false);

  const bookingId = params.get("bookingId") || "GVY-000001";
  const mode = params.get("mode") || "flight";
  const seats = (params.get("seats") || "12A").split(",");
  const name = params.get("name") || "Passenger";
  const fare = params.get("fare") || "2499";

  // Decode passengers array
  let passengers: Passenger[] = [];
  try {
    const raw = params.get("passengers");
    if (raw) passengers = JSON.parse(decodeURIComponent(raw));
  } catch {
    // ignore parse errors
  }

  // Fallback: construct minimal list from name + seats
  if (!passengers.length) {
    passengers = seats.map((_, i) => ({
      name: i === 0 ? name : `Passenger ${i + 1}`,
      age: "",
      gender: "",
      phone: "",
      email: "",
    }));
  }

  const typeIcon = mode === "flight" ? "✈️" : mode === "train" ? "🚆" : "🚌";
  const operator = mode === "flight" ? "IndiGo" : mode === "train" ? "Indian Railways" : "IntrCity SmartBus";
  const ticketNo = `TKT${bookingId.replace(/\D/g, "").padEnd(8, "0").slice(0, 8)}`;
  const ticketUrl = `${window.location.origin}/ticket?bookingId=${bookingId}&mode=${mode}&seats=${encodeURIComponent(seats.join(","))}&name=${encodeURIComponent(name)}&fare=${fare}&passengers=${encodeURIComponent(JSON.stringify(passengers))}`;

  const genderLabel = (g: string) => {
    if (g === "male") return "Male";
    if (g === "female") return "Female";
    if (g === "other") return "Other";
    if (g === "prefer_not") return "Undisclosed";
    return g;
  };

  return (
    <div className="min-h-screen py-10 px-4 print:py-0 print:px-0 print:bg-white">
      {showQR && <QRModal url={ticketUrl} onClose={() => setShowQR(false)} />}

      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8 print:hidden">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00d4aa]/20 text-[#00d4aa] text-sm font-semibold mb-4">
            <CheckCircle size={14} /> Booking Confirmed
          </div>
          <h1 className="font-display font-black text-3xl mb-2">Your GoVeya Ticket</h1>
          <p className="text-[var(--muted-foreground)] text-sm">
            Present this at boarding. Booking ID: <span className="font-mono text-[#4f6ef7]">{bookingId}</span>
          </p>
        </div>

        {/* Ticket card */}
        <div className="glass border border-[var(--border)] rounded-3xl overflow-hidden mb-6 print:border print:border-gray-300 print:rounded-none">
          {/* Header stripe */}
          <div className="bg-gradient-to-r from-[#4f6ef7] to-[#00d4aa] p-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                  <span className="text-white font-bold text-sm font-display">G</span>
                </div>
                <span className="font-display font-bold text-lg">GoVeya</span>
              </div>
              <span className="text-xl">{typeIcon}</span>
            </div>
            <div className="flex items-center gap-4">
              <div>
                <div className="text-white/70 text-xs">FROM</div>
                <div className="font-display font-black text-2xl">HYD</div>
                <div className="text-white/80 text-sm">Hyderabad</div>
              </div>
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-white/70 text-xs mb-1">07:00 → 08:10</div>
                  <div className="flex items-center gap-1">
                    <div className="h-px bg-white/40 w-12" />
                    <div className="text-white/90 text-xs">1h 10m</div>
                    <div className="h-px bg-white/40 w-12" />
                  </div>
                  <div className="text-white/70 text-xs mt-1">Direct</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white/70 text-xs">TO</div>
                <div className="font-display font-black text-2xl">BLR</div>
                <div className="text-white/80 text-sm">Bengaluru</div>
              </div>
            </div>
          </div>

          {/* Tear line */}
          <div className="flex items-center relative">
            <div className="absolute left-0 -top-4 w-8 h-8 rounded-full bg-[var(--background)] print:hidden" />
            <div className="absolute right-0 -top-4 w-8 h-8 rounded-full bg-[var(--background)] print:hidden" />
            <div className="flex-1 border-t border-dashed border-[var(--border)] mx-8" />
          </div>

          {/* Body */}
          <div className="p-6">
            {/* Booking summary */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-5 mb-6">
              {[
                { label: "Ticket No.", val: ticketNo, mono: true },
                { label: "Booking ID", val: bookingId, mono: true },
                { label: "Operator", val: operator },
                { label: "Date", val: new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) },
                { label: "Seats", val: seats.join(", "), mono: true },
                { label: "Class", val: mode === "flight" ? "Economy" : mode === "train" ? "3A" : "AC Sleeper" },
              ].map((item) => (
                <div key={item.label}>
                  <div className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium mb-1">{item.label}</div>
                  <div className={`font-bold text-sm ${item.mono ? "font-mono text-[#4f6ef7]" : ""}`}>{item.val}</div>
                </div>
              ))}
            </div>

            {/* Passenger details */}
            <div className="border-t border-[var(--border)] pt-5 mb-5">
              <div className="flex items-center gap-2 mb-4">
                <User size={14} className="text-[#4f6ef7]" />
                <span className="font-display font-bold text-sm uppercase tracking-wide text-[var(--muted-foreground)]">
                  Passenger Details
                </span>
              </div>

              <div className="flex flex-col gap-3">
                {passengers.map((p, i) => (
                  <div
                    key={i}
                    className="rounded-2xl border border-[var(--border)] bg-[var(--muted)]/40 p-4"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#4f6ef7] to-[#00d4aa] flex items-center justify-center text-white text-xs font-bold shrink-0">
                          {i + 1}
                        </div>
                        <span className="font-display font-bold text-sm">{p.name || `Passenger ${i + 1}`}</span>
                      </div>
                      <span className="font-mono text-xs text-[#4f6ef7] bg-[#4f6ef7]/10 px-2 py-0.5 rounded-full">
                        Seat {seats[i] || seats[0]}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      {p.age && (
                        <div>
                          <div className="text-[var(--muted-foreground)] mb-0.5">Age</div>
                          <div className="font-semibold">{p.age} yrs</div>
                        </div>
                      )}
                      {p.gender && (
                        <div>
                          <div className="text-[var(--muted-foreground)] mb-0.5">Gender</div>
                          <div className="font-semibold">{genderLabel(p.gender)}</div>
                        </div>
                      )}
                      {p.phone && (
                        <div>
                          <div className="text-[var(--muted-foreground)] mb-0.5">Phone</div>
                          <div className="font-semibold font-mono">{p.phone}</div>
                        </div>
                      )}
                      {p.email && (
                        <div className="col-span-2 sm:col-span-1">
                          <div className="text-[var(--muted-foreground)] mb-0.5">Email</div>
                          <div className="font-semibold truncate">{p.email}</div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Payment row + QR */}
            <div className="flex flex-col sm:flex-row items-center gap-6 pt-5 border-t border-[var(--border)]">
              <div className="flex-1 w-full">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-[var(--muted-foreground)]">Amount Paid</span>
                  <span className="font-mono font-black text-xl text-[#00d4aa]">₹{Number(fare).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-[var(--muted-foreground)]">Payment Status</span>
                  <span className="text-[#00d4aa] font-semibold flex items-center gap-1">
                    <CheckCircle size={12} /> Confirmed
                  </span>
                </div>
              </div>

              {/* Clickable QR */}
              <button
                onClick={() => setShowQR(true)}
                className="w-24 h-24 bg-white rounded-xl flex items-center justify-center p-2 hover:scale-105 transition-transform hover:shadow-lg hover:shadow-[#4f6ef7]/20 cursor-pointer group relative print:cursor-default"
                title="Click to view full QR code"
              >
                <QRCodeSVG
                  value={ticketUrl}
                  size={80}
                  bgColor="#ffffff"
                  fgColor="#06080f"
                  level="H"
                />
                <div className="absolute inset-0 rounded-xl bg-[#4f6ef7]/0 group-hover:bg-[#4f6ef7]/10 transition-colors flex items-center justify-center print:hidden">
                  <span className="text-[8px] font-bold text-[#4f6ef7] opacity-0 group-hover:opacity-100 bg-white/90 px-1 py-0.5 rounded absolute bottom-1">tap to scan</span>
                </div>
              </button>
            </div>
          </div>
        </div>

        <div className="flex gap-3 print:hidden">
          <button
            onClick={() => window.print()}
            className="flex-1 py-3 rounded-xl bg-[#4f6ef7] text-white font-bold text-sm hover:bg-[#3b5bdb] flex items-center justify-center gap-2"
          >
            <Download size={16} /> Download Ticket
          </button>
          <button onClick={() => navigate("/dashboard")}
            className="flex-1 py-3 rounded-xl glass border border-[var(--border)] text-sm font-medium flex items-center justify-center gap-2">
            My Bookings
          </button>
          <button onClick={() => navigate("/")}
            className="flex-1 py-3 rounded-xl glass border border-[var(--border)] text-sm font-medium">
            Home
          </button>
        </div>
      </div>
    </div>
  );
}
