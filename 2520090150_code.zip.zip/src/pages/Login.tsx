import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const [show, setShow] = useState(false);
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex items-center justify-center px-4 hero-gradient">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#4f6ef7] to-[#00d4aa] flex items-center justify-center">
              <span className="text-white font-bold font-display">G</span>
            </div>
            <span className="font-display font-black text-2xl">GoVeya</span>
          </div>
          <h1 className="font-display font-bold text-2xl mb-1">Welcome back</h1>
          <p className="text-[var(--muted-foreground)] text-sm">Sign in to manage your journeys</p>
        </div>
        <div className="glass rounded-2xl border border-[var(--border)] p-8">
          <div className="flex flex-col gap-4">
            <div>
              <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Email</label>
              <div className="mt-1 relative">
                <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                <input type="email" placeholder="you@example.com"
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
              </div>
            </div>
            <div>
              <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Password</label>
              <div className="mt-1 relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                <input type={show ? "text" : "password"} placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
                <button onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]">
                  {show ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>
            <button onClick={() => navigate("/dashboard")}
              className="w-full py-3 rounded-xl bg-[#4f6ef7] text-white font-bold text-sm hover:bg-[#3b5bdb] mt-2">
              Sign In
            </button>
          </div>
          <p className="text-center text-sm text-[var(--muted-foreground)] mt-5">
            Don't have an account?{" "}
            <Link to="/signup" className="text-[#4f6ef7] font-medium hover:underline">Sign Up</Link>
          </p>

          <div className="flex items-center gap-3 mt-5">
            <div className="flex-1 h-px bg-[var(--border)]" />
            <span className="text-xs text-[var(--muted-foreground)]">or</span>
            <div className="flex-1 h-px bg-[var(--border)]" />
          </div>

          <Link
            to="/admin/login"
            className="mt-4 flex items-center justify-center gap-2 w-full py-3 rounded-xl border border-[var(--border)] text-sm font-medium text-[var(--muted-foreground)] hover:border-[#4f6ef7] hover:text-[#4f6ef7] transition-all"
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
            Admin Login
          </Link>
        </div>
      </div>
    </div>
  );
}
