import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, Clock, CheckCircle, XCircle, Ticket, Download, X, Bell, CreditCard, Heart, ChevronRight, AlertTriangle } from "lucide-react";
import { SAMPLE_BOOKINGS } from "../data";

type Tab = "upcoming" | "previous" | "cancelled" | "history";

const STATUS_STYLE: Record<string, string> = {
  confirmed: "text-[#00d4aa] bg-[#00d4aa]/10",
  upcoming: "text-[#4f6ef7] bg-[#4f6ef7]/10",
  completed: "text-[var(--muted-foreground)] bg-[var(--muted)]",
  cancelled: "text-red-400 bg-red-400/10",
};

interface Booking {
  id: string;
  type: string;
  from: string;
  to: string;
  operator: string;
  date: string;
  seat: string;
  departure: string;
  amount: number;
  passenger: string;
  status: string;
}

function CancelModal({
  booking,
  onConfirm,
  onClose,
}: {
  booking: Booking;
  onConfirm: () => void;
  onClose: () => void;
}) {
  const [confirmed, setConfirmed] = useState(false);

  const handleConfirm = () => {
    setConfirmed(true);
    setTimeout(() => {
      onConfirm();
      onClose();
    }, 1200);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center px-4"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(10px)" }}
      onClick={onClose}
    >
      <div
        className="glass rounded-3xl border border-red-400/30 p-8 max-w-sm w-full"
        style={{ animation: "fadeInUp 0.3s ease forwards" }}
        onClick={(e) => e.stopPropagation()}
      >
        {confirmed ? (
          <div className="flex flex-col items-center gap-4 text-center py-4">
            <div className="w-16 h-16 rounded-full bg-red-400/20 flex items-center justify-center">
              <XCircle size={32} className="text-red-400" />
            </div>
            <div>
              <h3 className="font-display font-bold text-xl text-red-400 mb-1">Booking Cancelled</h3>
              <p className="text-[var(--muted-foreground)] text-sm">Refund will be processed in 5–7 business days.</p>
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-red-400/10 flex items-center justify-center shrink-0">
                <AlertTriangle size={20} className="text-red-400" />
              </div>
              <div>
                <h3 className="font-display font-bold text-lg">Cancel Booking?</h3>
                <p className="text-[var(--muted-foreground)] text-xs">This action cannot be undone.</p>
              </div>
            </div>

            {/* Booking summary */}
            <div className="bg-[var(--muted)] rounded-2xl p-4 mb-6 text-sm flex flex-col gap-2">
              <div className="flex justify-between">
                <span className="text-[var(--muted-foreground)]">Booking ID</span>
                <span className="font-mono font-bold text-[#4f6ef7] text-xs">{booking.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--muted-foreground)]">Route</span>
                <span className="font-medium">{booking.from} → {booking.to}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--muted-foreground)]">Date</span>
                <span className="font-medium">{booking.date}</span>
              </div>
              <div className="flex justify-between border-t border-[var(--border)] pt-2 mt-1">
                <span className="text-[var(--muted-foreground)]">Refund Amount</span>
                <span className="font-mono font-bold text-[#00d4aa]">₹{Math.round(booking.amount * 0.85).toLocaleString()}</span>
              </div>
              <p className="text-[10px] text-[var(--muted-foreground)]">* 15% cancellation fee applies. Refund in 5–7 business days.</p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={onClose}
                className="flex-1 py-3 rounded-xl glass border border-[var(--border)] text-sm font-medium hover:border-[#4f6ef7]/50"
              >
                Keep Booking
              </button>
              <button
                onClick={handleConfirm}
                className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm font-bold hover:bg-red-600 transition-colors"
              >
                Yes, Cancel
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>("upcoming");
  const navigate = useNavigate();

  // Local state to track cancellations on top of sample data
  const [bookings, setBookings] = useState<Booking[]>(SAMPLE_BOOKINGS as Booking[]);
  const [cancelTarget, setCancelTarget] = useState<Booking | null>(null);

  const handleCancelConfirm = (id: string) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status: "cancelled" } : b))
    );
  };

  const filtered = bookings.filter((b) => {
    if (tab === "upcoming") return b.status === "upcoming" || b.status === "confirmed";
    if (tab === "previous") return b.status === "completed";
    if (tab === "cancelled") return b.status === "cancelled";
    return true;
  });

  const cancelledCount = bookings.filter((b) => b.status === "cancelled").length;
  const upcomingCount = bookings.filter((b) => b.status === "upcoming" || b.status === "confirmed").length;

  return (
    <div className="min-h-screen py-10 px-4">
      {cancelTarget && (
        <CancelModal
          booking={cancelTarget}
          onConfirm={() => handleCancelConfirm(cancelTarget.id)}
          onClose={() => setCancelTarget(null)}
        />
      )}

      <div className="max-w-5xl mx-auto">
        {/* Profile card */}
        <div className="glass rounded-2xl border border-[var(--border)] p-6 mb-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#4f6ef7] to-[#00d4aa] flex items-center justify-center text-white font-display font-black text-2xl">
            A
          </div>
          <div className="flex-1">
            <h1 className="font-display font-black text-2xl mb-0.5">My GoVeya</h1>
            <p className="text-[var(--muted-foreground)] text-sm">arjun.sharma@example.com · +91 98765 43210</p>
          </div>
          <div className="flex gap-3">
            <div className="text-center px-4">
              <div className="font-display font-bold text-xl">{bookings.length}</div>
              <div className="text-xs text-[var(--muted-foreground)]">Trips</div>
            </div>
            <div className="text-center px-4 border-l border-[var(--border)]">
              <div className="font-display font-bold text-xl text-[#00d4aa]">
                ₹{bookings.filter(b => b.status !== "cancelled").reduce((s, b) => s + b.amount, 0).toLocaleString()}
              </div>
              <div className="text-xs text-[var(--muted-foreground)]">Total spent</div>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <aside className="lg:w-56 shrink-0">
            <div className="glass rounded-2xl border border-[var(--border)] overflow-hidden">
              {[
                { id: "upcoming", icon: <Clock size={16} />, label: "Upcoming Trips", count: upcomingCount },
                { id: "previous", icon: <CheckCircle size={16} />, label: "Previous Trips", count: null },
                { id: "cancelled", icon: <XCircle size={16} />, label: "Cancelled", count: cancelledCount || null },
                { id: "history", icon: <CreditCard size={16} />, label: "Payment History", count: null },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setTab(item.id as Tab)}
                  className={`w-full flex items-center gap-3 px-4 py-3.5 text-sm font-medium transition-all border-b border-[var(--border)] last:border-0 ${tab === item.id ? "bg-[#4f6ef7]/10 text-[#4f6ef7]" : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]"}`}
                >
                  {item.icon}
                  <span className="flex-1 text-left">{item.label}</span>
                  {item.count !== null && item.count > 0 && (
                    <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold ${tab === item.id ? "bg-[#4f6ef7] text-white" : "bg-[var(--muted)] text-[var(--muted-foreground)]"}`}>
                      {item.count}
                    </span>
                  )}
                  <ChevronRight size={14} />
                </button>
              ))}
            </div>

            {/* Quick links */}
            <div className="glass rounded-2xl border border-[var(--border)] mt-4 overflow-hidden">
              {[
                { icon: <Heart size={15} />, label: "Saved Journeys" },
                { icon: <Bell size={15} />, label: "Notifications" },
                { icon: <User size={15} />, label: "Edit Profile" },
              ].map((item) => (
                <button key={item.label} className="w-full flex items-center gap-3 px-4 py-3 text-sm text-[var(--muted-foreground)] hover:text-[var(--foreground)] border-b border-[var(--border)] last:border-0">
                  {item.icon} {item.label}
                </button>
              ))}
            </div>
          </aside>

          {/* Main content */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-col gap-4">
              {filtered.length === 0 && (
                <div className="glass rounded-2xl border border-[var(--border)] p-12 text-center">
                  <div className="text-4xl mb-3">🗓️</div>
                  <div className="font-display font-bold text-lg mb-1">No bookings here</div>
                  <div className="text-sm text-[var(--muted-foreground)] mb-4">Ready for your next adventure?</div>
                  <button onClick={() => navigate("/")} className="px-6 py-2.5 rounded-xl bg-[#4f6ef7] text-white text-sm font-bold hover:bg-[#3b5bdb]">
                    Search Tickets
                  </button>
                </div>
              )}

              {filtered.map((b) => (
                <div
                  key={b.id}
                  className={`glass rounded-2xl border p-5 transition-all ${b.status === "cancelled" ? "border-red-400/20 opacity-75" : "border-[var(--border)] hover:border-[#4f6ef7]/40"}`}
                >
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span>{b.type === "flight" ? "✈️" : b.type === "train" ? "🚆" : "🚌"}</span>
                        <span className="font-display font-bold text-base">{b.from} → {b.to}</span>
                      </div>
                      <div className="text-xs text-[var(--muted-foreground)]">{b.operator} · {b.date}</div>
                    </div>
                    <span className={`text-xs font-medium px-2.5 py-1 rounded-full shrink-0 ${STATUS_STYLE[b.status] || ""}`}>
                      {b.status.charAt(0).toUpperCase() + b.status.slice(1)}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm mb-4">
                    <div>
                      <div className="text-xs text-[var(--muted-foreground)]">Booking ID</div>
                      <div className="font-mono text-[#4f6ef7] font-bold text-xs">{b.id}</div>
                    </div>
                    <div>
                      <div className="text-xs text-[var(--muted-foreground)]">Seat</div>
                      <div className="font-mono font-bold">{b.seat}</div>
                    </div>
                    <div>
                      <div className="text-xs text-[var(--muted-foreground)]">Departure</div>
                      <div className="font-bold">{b.departure}</div>
                    </div>
                    <div>
                      <div className="text-xs text-[var(--muted-foreground)]">Amount</div>
                      <div className={`font-mono font-bold ${b.status === "cancelled" ? "line-through text-[var(--muted-foreground)]" : "text-[#00d4aa]"}`}>
                        ₹{b.amount.toLocaleString()}
                      </div>
                    </div>
                  </div>

                  {b.status === "cancelled" && (
                    <div className="mb-3 px-3 py-2 rounded-xl bg-red-400/5 border border-red-400/15 text-xs text-red-400">
                      Refund of ₹{Math.round(b.amount * 0.85).toLocaleString()} will be credited in 5–7 business days.
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2 pt-4 border-t border-[var(--border)]">
                    {b.status !== "cancelled" && (
                      <button
                        onClick={() => navigate(`/ticket?bookingId=${b.id}&mode=${b.type}&seats=${b.seat}&name=${b.passenger}&fare=${b.amount}`)}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#4f6ef7]/10 text-[#4f6ef7] text-xs font-semibold hover:bg-[#4f6ef7]/20"
                      >
                        <Ticket size={13} /> View Ticket
                      </button>
                    )}
                    {b.status !== "cancelled" && (
                      <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg glass border border-[var(--border)] text-xs font-medium hover:border-[#4f6ef7]/50">
                        <Download size={13} /> Download
                      </button>
                    )}
                    {(b.status === "upcoming" || b.status === "confirmed") && (
                      <button
                        onClick={() => setCancelTarget(b)}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-400/10 text-red-400 text-xs font-semibold hover:bg-red-400/20 ml-auto"
                      >
                        <X size={13} /> Cancel Booking
                      </button>
                    )}
                    {b.status === "cancelled" && (
                      <button
                        onClick={() => navigate("/")}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#4f6ef7]/10 text-[#4f6ef7] text-xs font-semibold hover:bg-[#4f6ef7]/20"
                      >
                        Book Again →
                      </button>
                    )}
                  </div>
                </div>
              ))}

              {tab === "history" && (
                <div className="glass rounded-2xl border border-[var(--border)] p-5">
                  <h3 className="font-display font-bold text-sm mb-4">Payment History</h3>
                  <div className="flex flex-col gap-2">
                    {bookings.map((b) => (
                      <div key={b.id} className="flex items-center justify-between py-3 border-b border-[var(--border)] last:border-0">
                        <div>
                          <div className="text-sm font-medium">{b.from} → {b.to}</div>
                          <div className="text-xs text-[var(--muted-foreground)]">{b.id} · {b.date}</div>
                        </div>
                        <div className="text-right">
                          <div className={`font-mono font-bold ${b.status === "cancelled" ? "line-through text-[var(--muted-foreground)]" : "text-[#00d4aa]"}`}>
                            ₹{b.amount.toLocaleString()}
                          </div>
                          <div className={`text-xs ${b.status === "cancelled" ? "text-red-400" : "text-[#00d4aa]"}`}>
                            {b.status === "cancelled" ? "Refunded" : "Paid"}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
