import { useState, useMemo } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { Filter, ArrowRight, Star, Clock, Wifi, Zap, ChevronDown, ChevronUp, SlidersHorizontal } from "lucide-react";
import { BUSES, TRAINS, FLIGHTS } from "../data";
import SearchPanel from "../components/SearchPanel";

type SortKey = "cheapest" | "fastest" | "best" | "recommended";

function RiskBadge({ risk }: { risk: string }) {
  const color = risk === "Low" ? "text-[#00d4aa] bg-[#00d4aa]/10" : risk === "Medium" ? "text-amber-400 bg-amber-400/10" : "text-red-400 bg-red-400/10";
  return <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${color}`}>{risk} risk</span>;
}

export default function SearchResults() {
  const { mode } = useParams<{ mode: string }>();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [sort, setSort] = useState<SortKey>("recommended");
  const [maxPrice, setMaxPrice] = useState(10000);
  const [showFilters, setShowFilters] = useState(false);
  const [stopFilter, setStopFilter] = useState<string>("any");

  const from = params.get("from") || "Hyderabad";
  const to = params.get("to") || "Bengaluru";

  const raw = useMemo(() => {
    if (mode === "bus") return BUSES;
    if (mode === "train") return TRAINS;
    return FLIGHTS;
  }, [mode]);

  const results = useMemo(() => {
    let data = [...raw].filter((r) => r.price <= maxPrice);
    if (stopFilter === "direct") data = data.filter((r) => r.stops === 0);
    if (sort === "cheapest") data.sort((a, b) => a.price - b.price);
    else if (sort === "fastest") data.sort((a, b) => a.duration.localeCompare(b.duration));
    else if (sort === "best") data.sort((a, b) => b.rating - a.rating);
    return data;
  }, [raw, sort, maxPrice, stopFilter]);

  const typeLabel = mode === "bus" ? "Bus" : mode === "train" ? "Train" : "Flight";
  const typeIcon = mode === "bus" ? "🚌" : mode === "train" ? "🚆" : "✈️";

  const passengers = params.get("passengers") || "1";
  const handleSelect = (id: string) => {
    navigate(`/seat-selection?mode=${mode}&id=${id}&passengers=${passengers}`);
  };

  return (
    <div className="min-h-screen bg-[var(--background)]">
      {/* Search bar */}
      <div className="bg-[var(--card)] border-b border-[var(--border)] py-6 px-4">
        <div className="max-w-4xl mx-auto">
          <SearchPanel defaultTab={mode as any} />
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8 flex gap-6">
        {/* Filters sidebar */}
        <aside className={`w-64 shrink-0 hidden md:block`}>
          <div className="glass rounded-2xl p-5 border border-[var(--border)] sticky top-24">
            <div className="flex items-center gap-2 font-display font-bold text-sm mb-5">
              <SlidersHorizontal size={16} className="text-[#4f6ef7]" /> Filters
            </div>

            <div className="mb-5">
              <div className="text-xs text-[var(--muted-foreground)] font-medium uppercase tracking-wide mb-3">Max Price</div>
              <input
                type="range" min={300} max={10000} step={100} value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[#4f6ef7]"
              />
              <div className="flex justify-between text-xs text-[var(--muted-foreground)] mt-1">
                <span>₹300</span>
                <span className="font-mono text-[#4f6ef7]">₹{maxPrice.toLocaleString()}</span>
              </div>
            </div>

            <div className="mb-5">
              <div className="text-xs text-[var(--muted-foreground)] font-medium uppercase tracking-wide mb-3">Stops</div>
              {["any", "direct", "1stop"].map((s) => (
                <label key={s} className="flex items-center gap-2 mb-2 cursor-pointer">
                  <input type="radio" name="stops" value={s} checked={stopFilter === s} onChange={() => setStopFilter(s)} className="accent-[#4f6ef7]" />
                  <span className="text-sm capitalize">{s === "any" ? "Any" : s === "direct" ? "Direct only" : "1 stop"}</span>
                </label>
              ))}
            </div>

            <div>
              <div className="text-xs text-[var(--muted-foreground)] font-medium uppercase tracking-wide mb-3">Departure Time</div>
              {["Early (12am–6am)", "Morning (6am–12pm)", "Afternoon (12pm–6pm)", "Evening (6pm–12am)"].map((t) => (
                <label key={t} className="flex items-center gap-2 mb-2 cursor-pointer">
                  <input type="checkbox" className="accent-[#4f6ef7]" defaultChecked />
                  <span className="text-xs text-[var(--muted-foreground)]">{t}</span>
                </label>
              ))}
            </div>
          </div>
        </aside>

        {/* Results */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
            <div>
              <h1 className="font-display font-bold text-xl">
                {typeIcon} {from} → {to}
              </h1>
              <p className="text-sm text-[var(--muted-foreground)]">{results.length} {typeLabel.toLowerCase()}s available</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {(["recommended", "cheapest", "fastest", "best"] as SortKey[]).map((s) => (
                <button
                  key={s}
                  onClick={() => setSort(s)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${sort === s ? "bg-[#4f6ef7] text-white border-[#4f6ef7]" : "border-[var(--border)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]"}`}
                >
                  {s.charAt(0).toUpperCase() + s.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Cards */}
          <div className="flex flex-col gap-4">
            {results.length === 0 && (
              <div className="glass rounded-2xl p-12 text-center border border-[var(--border)]">
                <div className="text-4xl mb-3">🔍</div>
                <div className="font-display font-bold text-lg mb-1">No results found</div>
                <div className="text-sm text-[var(--muted-foreground)]">Try adjusting your filters</div>
              </div>
            )}
            {results.map((r: any) => (
              <div key={r.id} className="glass rounded-2xl p-5 border border-[var(--border)] hover:border-[#4f6ef7]/50 transition-all">
                <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                  {/* Operator */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-display font-bold text-sm">{r.operator || r.airline || r.name}</span>
                      <span className="font-mono text-xs text-[var(--muted-foreground)]">#{r.id}</span>
                    </div>
                    <div className="text-xs text-[var(--muted-foreground)]">{r.type || r.class || r.class}</div>
                  </div>

                  {/* Times */}
                  <div className="flex items-center gap-4 sm:gap-6">
                    <div className="text-center">
                      <div className="font-display font-bold text-lg">{r.departure}</div>
                      <div className="text-xs text-[var(--muted-foreground)]">{from}</div>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                      <div className="text-xs text-[var(--muted-foreground)]">{r.duration}</div>
                      <div className="w-24 h-px bg-[var(--border)] relative">
                        <div className="absolute left-1/2 -translate-x-1/2 -top-1 w-2 h-2 rounded-full bg-[#4f6ef7]" />
                      </div>
                      <div className="text-xs text-[var(--muted-foreground)]">{r.stops === 0 ? "Direct" : `${r.stops} stop`}</div>
                    </div>
                    <div className="text-center">
                      <div className="font-display font-bold text-lg">{r.arrival}</div>
                      <div className="text-xs text-[var(--muted-foreground)]">{to}</div>
                    </div>
                  </div>

                  {/* Rating + Seats */}
                  <div className="flex flex-col items-center gap-1">
                    <div className="flex items-center gap-1">
                      <Star size={12} className="fill-amber-400 text-amber-400" />
                      <span className="text-sm font-semibold">{r.rating}</span>
                    </div>
                    <div className="text-xs text-[var(--muted-foreground)]">{r.seats} seats left</div>
                  </div>

                  {/* Price + CTA */}
                  <div className="flex flex-col items-end gap-2 sm:min-w-[120px]">
                    <div className="font-display font-black text-2xl text-[#00d4aa]">₹{r.price.toLocaleString()}</div>
                    <button
                      onClick={() => handleSelect(r.id)}
                      className="px-5 py-2.5 rounded-xl bg-[#4f6ef7] text-white text-sm font-bold hover:bg-[#3b5bdb] flex items-center gap-1"
                    >
                      Select <ArrowRight size={14} />
                    </button>
                  </div>
                </div>

                {/* Amenities */}
                {r.amenities && r.amenities.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-[var(--border)]">
                    {r.amenities.map((a: string) => (
                      <span key={a} className="text-xs px-2 py-1 rounded-lg bg-[var(--muted)] text-[var(--muted-foreground)]">{a}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
