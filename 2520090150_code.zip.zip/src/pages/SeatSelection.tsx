import { useState, useMemo } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { ArrowRight, Users, Info, Bus, Train, Plane } from "lucide-react";
import { BUSES, TRAINS, FLIGHTS } from "../data";

// Deterministically generate occupied seats from the transport id
function getOccupied(id: string, total: number, available: number): Set<number> {
  const occupied = new Set<number>();
  const occupiedCount = total - available;
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash * 31 + id.charCodeAt(i)) & 0xffffffff;
  let n = Math.abs(hash);
  while (occupied.size < occupiedCount) {
    occupied.add((n % total) + 1);
    n = (n * 1664525 + 1013904223) & 0xffffffff;
    n = Math.abs(n);
  }
  return occupied;
}

// ── BUS LAYOUT ─────────────────────────────────────────────────────────────
function BusLayout({ totalSeats, occupied, selected, max, onToggle }: {
  totalSeats: number; occupied: Set<number>; selected: number[]; max: number; onToggle: (n: number) => void;
}) {
  const rows = Math.ceil(totalSeats / 4);
  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className="bg-[var(--muted)] rounded-t-3xl w-48 h-10 flex items-center justify-center text-xs text-[var(--muted-foreground)] mb-2 font-medium">
        🚌 Driver
      </div>
      {Array.from({ length: rows }, (_, row) => {
        const seats = [row * 4 + 1, row * 4 + 2, row * 4 + 3, row * 4 + 4].filter(s => s <= totalSeats);
        return (
          <div key={row} className="flex items-center gap-1">
            {seats.slice(0, 2).map(n => <SeatBtn key={n} n={n} occupied={occupied} selected={selected} max={max} onToggle={onToggle} />)}
            <div className="w-6 text-center text-[10px] text-[var(--muted-foreground)] font-mono">{row + 1}</div>
            {seats.slice(2).map(n => <SeatBtn key={n} n={n} occupied={occupied} selected={selected} max={max} onToggle={onToggle} />)}
          </div>
        );
      })}
    </div>
  );
}

// ── TRAIN LAYOUT ────────────────────────────────────────────────────────────
function TrainLayout({ totalSeats, occupied, selected, max, onToggle, coaches }: {
  totalSeats: number; occupied: Set<number>; selected: number[]; max: number; onToggle: (n: number) => void; coaches: string[];
}) {
  const berths = ["LB", "MB", "UB", "SLB", "SUB"];
  const seatsPerBay = 5;
  const bays = Math.ceil(totalSeats / seatsPerBay);
  return (
    <div className="flex flex-col gap-3">
      {coaches.slice(0, Math.ceil(bays / 4)).map((coach, ci) => (
        <div key={coach} className="glass rounded-xl p-4 border border-[var(--border)]">
          <div className="text-xs font-mono text-[#4f6ef7] font-bold mb-3">Coach {coach}</div>
          <div className="flex flex-col gap-2">
            {Array.from({ length: Math.min(4, bays - ci * 4) }, (_, bi) => {
              const bayIndex = ci * 4 + bi;
              return (
                <div key={bi} className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] text-[var(--muted-foreground)] w-8 font-mono">B{bayIndex + 1}</span>
                  {berths.map((berth, berthIdx) => {
                    const n = bayIndex * seatsPerBay + berthIdx + 1;
                    if (n > totalSeats) return null;
                    return (
                      <button key={berth} onClick={() => !occupied.has(n) && onToggle(n)}
                        className={`flex flex-col items-center gap-0.5 px-2 py-2 rounded-lg border transition-all text-center min-w-[44px] ${
                          occupied.has(n) ? "opacity-30 cursor-not-allowed bg-[var(--muted)] border-[var(--border)]" :
                          selected.includes(n) ? "bg-[#4f6ef7] text-white border-[#4f6ef7]" :
                          selected.length >= max ? "opacity-40 cursor-not-allowed bg-[var(--muted)] border-[var(--border)]" :
                          "bg-[var(--muted)] border-[var(--border)] hover:border-[#4f6ef7] hover:bg-[#4f6ef7]/10"
                        }`}
                      >
                        <span className="font-mono text-[10px] font-bold">{n}</span>
                        <span className="text-[9px] leading-tight">{berth}</span>
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── FLIGHT LAYOUT ───────────────────────────────────────────────────────────
function FlightLayout({ totalSeats, occupied, selected, max, onToggle, flightClass }: {
  totalSeats: number; occupied: Set<number>; selected: number[]; max: number; onToggle: (n: number) => void; flightClass: string;
}) {
  const isBusiness = flightClass === "Business";
  const cols = isBusiness ? ["A", "C", "D", "F"] : ["A", "B", "C", "D", "E", "F"];
  const rows = Math.ceil(totalSeats / cols.length);
  const businessRows = isBusiness ? rows : 3;

  return (
    <div className="overflow-x-auto">
      <div className="inline-flex flex-col gap-1 min-w-max">
        {/* Nose */}
        <div className="flex justify-center mb-2">
          <div className="w-16 h-8 rounded-t-full bg-[var(--muted)] flex items-center justify-center text-xs text-[var(--muted-foreground)]">✈️</div>
        </div>
        {/* Col headers */}
        <div className="flex items-center gap-1 mb-1 px-8">
          {cols.map((c, ci) => (
            <div key={c}>
              <span className="w-9 inline-block text-center text-xs text-[var(--muted-foreground)] font-mono">{c}</span>
              {(isBusiness ? ci === 1 : ci === 2) && <span className="w-5 inline-block" />}
            </div>
          ))}
        </div>
        {Array.from({ length: rows }, (_, rowIdx) => {
          const row = rowIdx + 1;
          const isBizRow = row <= businessRows && !isBusiness;
          return (
            <div key={row}>
              {isBizRow && row === 1 && (
                <div className="text-center text-[10px] text-amber-400 font-semibold mb-1 tracking-widest">BUSINESS CLASS</div>
              )}
              {!isBizRow && row === businessRows + 1 && (
                <div className="flex items-center gap-2 my-2">
                  <div className="flex-1 h-px border-t border-dashed border-[var(--border)]" />
                  <span className="text-[10px] text-[var(--muted-foreground)]">ECONOMY CLASS</span>
                  <div className="flex-1 h-px border-t border-dashed border-[var(--border)]" />
                </div>
              )}
              <div className="flex items-center gap-1">
                <span className="w-6 text-right text-[10px] text-[var(--muted-foreground)] font-mono mr-1">{row}</span>
                {cols.map((col, ci) => {
                  const seatNum = rowIdx * cols.length + ci + 1;
                  if (seatNum > totalSeats) return <div key={col} className="w-9" />;
                  return (
                    <div key={col}>
                      <button
                        onClick={() => !occupied.has(seatNum) && onToggle(seatNum)}
                        className={`w-9 h-9 rounded-md text-[10px] font-mono font-bold border transition-all ${
                          occupied.has(seatNum) ? "opacity-30 cursor-not-allowed bg-[var(--muted)] border-[var(--border)]" :
                          selected.includes(seatNum) ? "bg-[#4f6ef7] text-white border-[#4f6ef7]" :
                          selected.length >= max ? "opacity-40 cursor-not-allowed bg-[var(--muted)] border-[var(--border)]" :
                          isBizRow ? "bg-amber-400/15 border-amber-400/40 text-amber-400 hover:bg-amber-400/30" :
                          "bg-[var(--muted)] border-[var(--border)] hover:border-[#4f6ef7] hover:bg-[#4f6ef7]/10"
                        }`}
                      >
                        {col}
                      </button>
                      {(isBusiness ? ci === 1 : ci === 2) && <span className="w-5 inline-block" />}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── SHARED SEAT BUTTON ──────────────────────────────────────────────────────
function SeatBtn({ n, occupied, selected, max, onToggle }: {
  n: number; occupied: Set<number>; selected: number[]; max: number; onToggle: (n: number) => void;
}) {
  const isOccupied = occupied.has(n);
  const isSelected = selected.includes(n);
  const isFull = !isSelected && selected.length >= max;
  return (
    <button
      onClick={() => !isOccupied && !isFull && onToggle(n)}
      className={`w-10 h-10 rounded-lg text-xs font-mono font-bold border transition-all ${
        isOccupied ? "opacity-30 cursor-not-allowed bg-[var(--muted)] border-[var(--border)]" :
        isSelected ? "bg-[#4f6ef7] text-white border-[#4f6ef7] scale-105" :
        isFull ? "opacity-40 cursor-not-allowed bg-[var(--muted)] border-[var(--border)]" :
        "bg-[var(--muted)] border-[var(--border)] hover:border-[#4f6ef7] hover:bg-[#4f6ef7]/10"
      }`}
    >
      {n}
    </button>
  );
}

// ── MAIN PAGE ───────────────────────────────────────────────────────────────
export default function SeatSelection() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const mode = searchParams.get("mode") || "flight";
  const id = searchParams.get("id") || "";
  const passengersParam = Number(searchParams.get("passengers") || 1);

  const [passengers, setPassengers] = useState(passengersParam);
  const [selected, setSelected] = useState<number[]>([]);

  // Find the actual transport
  const transport = useMemo(() => {
    if (mode === "bus") return BUSES.find(b => b.id === id) || BUSES[0];
    if (mode === "train") return TRAINS.find(t => t.id === id) || TRAINS[0];
    return FLIGHTS.find(f => f.id === id) || FLIGHTS[0];
  }, [mode, id]);

  const totalSeats = mode === "bus" ? 40 : mode === "train" ? 72 : (transport as any).seats * 2;
  const occupied = useMemo(() => getOccupied(transport.id, totalSeats, transport.seats), [transport, totalSeats]);

  const onToggle = (n: number) => {
    setSelected(prev =>
      prev.includes(n) ? prev.filter(x => x !== n) : prev.length < passengers ? [...prev, n] : prev
    );
  };

  const farePerSeat = transport.price;
  const totalFare = selected.length * farePerSeat;

  const handleContinue = () => {
    navigate(`/passenger-details?mode=${mode}&id=${id}&seats=${selected.join(",")}&fare=${totalFare}`);
  };

  const typeIcon = mode === "bus" ? <Bus size={16} /> : mode === "train" ? <Train size={16} /> : <Plane size={16} />;
  const operatorName = (transport as any).operator || (transport as any).airline;

  return (
    <div className="min-h-screen py-10 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="font-display font-black text-3xl mb-1">Select Seats</h1>
          <div className="flex items-center gap-2 text-sm text-[var(--muted-foreground)]">
            {typeIcon}
            <span>{operatorName}</span>
            <span className="font-mono text-xs">#{transport.id}</span>
            <span>·</span>
            <span>{(transport as any).from} → {(transport as any).to}</span>
            <span>·</span>
            <span>{transport.seats} seats available</span>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Seat map */}
          <div className="flex-1 glass rounded-2xl border border-[var(--border)] p-6">
            {/* Passenger count selector */}
            <div className="flex items-center justify-between mb-5 pb-5 border-b border-[var(--border)]">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Users size={16} className="text-[#4f6ef7]" />
                Passengers
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => { setPassengers(p => Math.max(1, p - 1)); setSelected([]); }}
                  className="w-8 h-8 rounded-lg glass border border-[var(--border)] flex items-center justify-center font-bold hover:border-[#4f6ef7]">−</button>
                <span className="font-display font-bold text-lg w-6 text-center">{passengers}</span>
                <button onClick={() => { setPassengers(p => Math.min(6, p + 1)); setSelected([]); }}
                  className="w-8 h-8 rounded-lg glass border border-[var(--border)] flex items-center justify-center font-bold hover:border-[#4f6ef7]">+</button>
              </div>
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-4 mb-5">
              {[
                { cls: "bg-[var(--muted)] border-[var(--border)]", label: "Available" },
                { cls: "bg-[#4f6ef7] border-[#4f6ef7]", label: "Selected" },
                { cls: "bg-[var(--muted)] border-[var(--border)] opacity-30", label: "Occupied" },
                ...(mode === "flight" ? [{ cls: "bg-amber-400/15 border-amber-400/40", label: "Business" }] : []),
              ].map(l => (
                <div key={l.label} className="flex items-center gap-1.5 text-xs text-[var(--muted-foreground)]">
                  <div className={`w-4 h-4 rounded border ${l.cls}`} />
                  {l.label}
                </div>
              ))}
            </div>

            {/* Progress */}
            <div className="mb-5 p-3 rounded-xl bg-[var(--muted)] flex items-center justify-between text-sm">
              <span className="text-[var(--muted-foreground)]">Select <strong className="text-[var(--foreground)]">{passengers}</strong> seat{passengers > 1 ? "s" : ""}</span>
              <span className={`font-bold ${selected.length === passengers ? "text-[#00d4aa]" : "text-[#4f6ef7]"}`}>
                {selected.length} / {passengers} selected
              </span>
            </div>

            <div className="flex justify-center overflow-auto">
              {mode === "bus" && (
                <BusLayout totalSeats={totalSeats} occupied={occupied} selected={selected} max={passengers} onToggle={onToggle} />
              )}
              {mode === "train" && (
                <TrainLayout
                  totalSeats={totalSeats} occupied={occupied} selected={selected} max={passengers} onToggle={onToggle}
                  coaches={(transport as any).coaches || ["S1", "S2", "B1", "B2"]}
                />
              )}
              {(mode === "flight" || mode === "combined") && (
                <FlightLayout
                  totalSeats={totalSeats} occupied={occupied} selected={selected} max={passengers} onToggle={onToggle}
                  flightClass={(transport as any).class || "Economy"}
                />
              )}
            </div>
          </div>

          {/* Summary panel */}
          <div className="lg:w-72 shrink-0">
            <div className="glass rounded-2xl border border-[var(--border)] p-6 sticky top-24">
              <h3 className="font-display font-bold text-base mb-4">Booking Summary</h3>
              <div className="flex flex-col gap-3 text-sm mb-5">
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Operator</span><span className="font-medium text-right text-xs">{operatorName}</span></div>
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Route</span><span className="font-medium">{(transport as any).from?.slice(0,3)} → {(transport as any).to?.slice(0,3)}</span></div>
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Departure</span><span className="font-mono">{transport.departure}</span></div>
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Passengers</span><span className="font-bold">{passengers}</span></div>
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Selected</span>
                  <span className="font-mono text-[#4f6ef7] font-bold text-xs text-right max-w-[120px] break-words">
                    {selected.length > 0 ? selected.join(", ") : "—"}
                  </span>
                </div>
                <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Fare/seat</span><span className="font-mono">₹{farePerSeat.toLocaleString()}</span></div>
                <div className="border-t border-[var(--border)] pt-3 flex justify-between">
                  <span className="font-bold">Total</span>
                  <span className="font-mono font-black text-xl text-[#00d4aa]">₹{totalFare.toLocaleString()}</span>
                </div>
              </div>

              <button
                onClick={handleContinue}
                disabled={selected.length !== passengers}
                className="w-full py-3 rounded-xl bg-[#4f6ef7] text-white font-bold text-sm hover:bg-[#3b5bdb] disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                Continue <ArrowRight size={16} />
              </button>

              {selected.length < passengers && (
                <div className="flex items-center gap-2 mt-3 text-xs text-[var(--muted-foreground)]">
                  <Info size={12} /> Select {passengers - selected.length} more seat{passengers - selected.length > 1 ? "s" : ""} to continue
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
