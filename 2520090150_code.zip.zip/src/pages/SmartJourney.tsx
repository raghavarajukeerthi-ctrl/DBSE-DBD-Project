import React, { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Calendar, Users, ArrowRight, ArrowLeftRight, Plus, X, Zap, AlertTriangle, CheckCircle, Clock, Leaf, IndianRupee, Timer, Trophy, Star } from "lucide-react";
import { SMART_JOURNEYS } from "../data";
import LocationPicker from "../components/LocationPicker";

const RISK_CONFIG: Record<string, { color: string; bg: string; icon: React.ReactNode }> = {
  Low: { color: "text-[#00d4aa]", bg: "bg-[#00d4aa]/10", icon: <CheckCircle size={14} /> },
  Medium: { color: "text-amber-400", bg: "bg-amber-400/10", icon: <AlertTriangle size={14} /> },
  High: { color: "text-red-400", bg: "bg-red-400/10", icon: <AlertTriangle size={14} /> },
};

// Parse duration string like "10h 30m" or "2h" into minutes
function parseDuration(d: string): number {
  const hMatch = d.match(/(\d+)h/);
  const mMatch = d.match(/(\d+)m/);
  return (hMatch ? parseInt(hMatch[1]) * 60 : 0) + (mMatch ? parseInt(mMatch[1]) : 0);
}

// Get recommendation label based on how well an option fits the time budget
function getRecommendationLabel(optMins: number, limitMins: number, price: number, budget: number): {
  label: string; color: string; bg: string; icon: React.ReactNode;
} | null {
  const timeFit = optMins <= limitMins;
  const priceFit = price <= budget;
  if (timeFit && priceFit && optMins <= limitMins * 0.7) return { label: "Best Fit", color: "text-[#00d4aa]", bg: "bg-[#00d4aa]/15", icon: <Trophy size={13} /> };
  if (timeFit && priceFit) return { label: "Recommended", color: "text-[#4f6ef7]", bg: "bg-[#4f6ef7]/15", icon: <Star size={13} /> };
  if (timeFit && !priceFit) return { label: "Fits Time", color: "text-amber-400", bg: "bg-amber-400/10", icon: <Clock size={13} /> };
  return null;
}

function JourneyCard({ option, onSelect, timeLimitMins, budget, passengers, isBest }: {
  option: any; onSelect: () => void; timeLimitMins: number | null; budget: number; passengers: number; isBest: boolean;
}) {
  const risk = RISK_CONFIG[option.risk] || RISK_CONFIG.Low;
  const [showBackup, setShowBackup] = useState(false);
  const optMins = parseDuration(option.duration);
  const rec = timeLimitMins ? getRecommendationLabel(optMins, timeLimitMins, option.price, budget) : null;
  const fitsTime = timeLimitMins ? optMins <= timeLimitMins : true;
  const overTime = timeLimitMins ? optMins > timeLimitMins : false;
  const overBy = timeLimitMins ? optMins - timeLimitMins : 0;

  return (
    <div className={`glass rounded-2xl border overflow-hidden transition-all ${isBest ? "border-[#00d4aa]/60 shadow-lg shadow-[#00d4aa]/10" : overTime ? "border-red-400/20 opacity-70" : "border-[var(--border)] hover:border-[#4f6ef7]/50"}`}>
      {isBest && (
        <div className="bg-gradient-to-r from-[#00d4aa] to-[#4f6ef7] px-5 py-2 flex items-center gap-2 text-white text-xs font-bold">
          <Trophy size={13} /> Best match for your time — fastest option within your limit
        </div>
      )}
      {overTime && timeLimitMins !== null && (
        <div className="bg-red-400/10 border-b border-red-400/20 px-5 py-2 flex items-center gap-2 text-red-400 text-xs font-medium">
          <Clock size={13} /> Exceeds your time limit by {Math.floor(overBy / 60)}h {overBy % 60}m
        </div>
      )}

      <div className="p-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-2xl">{option.icon}</span>
              <span className="font-display font-bold text-base">{option.label}</span>
            </div>
            <div className="text-xs text-[var(--muted-foreground)]">{option.type === "combined" ? "Multi-modal journey" : option.type.charAt(0).toUpperCase() + option.type.slice(1)}</div>
          </div>
          <div className="flex flex-col items-end gap-1.5">
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${risk.color} ${risk.bg}`}>
              {risk.icon} {option.risk} Risk
            </div>
            {rec && (
              <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${rec.color} ${rec.bg}`}>
                {rec.icon} {rec.label}
              </div>
            )}
          </div>
        </div>

        {/* Time progress bar — shown when user set a limit */}
        {timeLimitMins !== null && (
          <div className="mb-4">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-[var(--muted-foreground)]">Journey time</span>
              <span className={`font-mono font-bold ${fitsTime ? "text-[#00d4aa]" : "text-red-400"}`}>{option.duration}</span>
            </div>
            <div className="h-2 rounded-full bg-[var(--muted)] overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${fitsTime ? "bg-gradient-to-r from-[#4f6ef7] to-[#00d4aa]" : "bg-red-400"}`}
                style={{ width: `${Math.min((optMins / timeLimitMins) * 100, 100)}%` }}
              />
            </div>
            <div className="text-[10px] text-[var(--muted-foreground)] mt-1">
              {fitsTime
                ? `${Math.floor((timeLimitMins - optMins) / 60)}h ${(timeLimitMins - optMins) % 60}m under your limit`
                : `${Math.floor(overBy / 60)}h ${overBy % 60}m over your limit`}
            </div>
          </div>
        )}

        {/* Segments */}
        <div className="flex flex-col gap-2 mb-5">
          {option.segments.map((seg: any, i: number) => (
            <div key={i} className="flex items-center gap-3 bg-[var(--muted)] rounded-xl px-4 py-3">
              <span className="text-base">{seg.mode === "Flight" ? "✈️" : seg.mode === "Train" ? "🚆" : "🚌"}</span>
              <div className="flex-1">
                <div className="text-xs text-[var(--muted-foreground)]">{seg.mode}</div>
                <div className="text-sm font-medium">{seg.operator}</div>
              </div>
              <div className="text-right">
                <div className="font-mono text-sm font-bold">{seg.dep}</div>
                <div className="text-xs text-[var(--muted-foreground)]">→ {seg.arr}</div>
              </div>
            </div>
          ))}
          {option.connectionTime && (
            <div className="flex items-center gap-2 px-4 py-2 bg-amber-400/10 rounded-xl border border-amber-400/20">
              <Clock size={14} className="text-amber-400" />
              <span className="text-xs text-amber-400 font-medium">
                {option.connectionTime} connection time — {option.risk === "Medium" ? "may be tight" : "safe buffer"}
              </span>
              <button
                onClick={() => setShowBackup(!showBackup)}
                className="ml-auto text-xs text-[#4f6ef7] font-semibold hover:underline"
              >
                {showBackup ? "Hide" : "Find Backup →"}
              </button>
            </div>
          )}
        </div>

        {showBackup && (
          <div className="mb-5 p-4 rounded-xl bg-[var(--muted)] border border-[var(--border)]">
            <div className="font-display font-bold text-sm mb-3 flex items-center gap-2">
              <Zap size={14} className="text-[#4f6ef7]" /> GoVeya Backup Journey
            </div>
            <div className="text-xs text-[var(--muted-foreground)] mb-3">Alternatives if you miss your connection:</div>
            {[
              { mode: "🚌", label: "Next KSRTC Bus", dep: "13:30", arr: "19:00", price: "₹350", risk: "Low" },
              { mode: "✈️", label: "IndiGo 6E588", dep: "14:15", arr: "15:25", price: "₹2,999", risk: "Low" },
            ].map((b) => (
              <div key={b.label} className="flex items-center gap-3 p-3 rounded-lg bg-[var(--card)] mb-2 border border-[var(--border)]">
                <span>{b.mode}</span>
                <div className="flex-1">
                  <div className="text-sm font-medium">{b.label}</div>
                  <div className="text-xs text-[var(--muted-foreground)]">{b.dep} → {b.arr}</div>
                </div>
                <span className="font-mono text-sm text-[#00d4aa]">{b.price}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-[#00d4aa]/10 text-[#00d4aa]">{b.risk} Risk</span>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          {[
            { icon: <Clock size={14} />, label: "Duration", val: option.duration },
            { icon: <IndianRupee size={14} />, label: "Total Price", val: `₹${option.price.toLocaleString()}` },
            { icon: <ArrowRight size={14} />, label: "Transfers", val: option.transfers === 0 ? "Direct" : `${option.transfers}` },
            { icon: <Leaf size={14} />, label: "Eco Impact", val: option.eco },
          ].map((s) => (
            <div key={s.label} className={`rounded-xl p-3 text-center ${s.label === "Duration" && isBest ? "bg-[#00d4aa]/10 border border-[#00d4aa]/20" : "bg-[var(--muted)]"}`}>
              <div className={`flex justify-center mb-1 ${s.label === "Duration" && isBest ? "text-[#00d4aa]" : "text-[var(--muted-foreground)]"}`}>{s.icon}</div>
              <div className={`font-bold text-sm ${s.label === "Duration" && isBest ? "text-[#00d4aa]" : ""}`}>{s.val}</div>
              <div className="text-xs text-[var(--muted-foreground)]">{s.label}</div>
            </div>
          ))}
        </div>

        <button
          onClick={onSelect}
          className={`w-full py-3 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2 ${isBest ? "bg-gradient-to-r from-[#00d4aa] to-[#4f6ef7] hover:opacity-90" : "bg-[#4f6ef7] hover:bg-[#3b5bdb]"}`}
        >
          Select Journey <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

// Time input widget: hours + minutes
function TimeInput({ value, onChange }: { value: number; onChange: (mins: number) => void }) {
  const hours = Math.floor(value / 60);
  const mins = value % 60;

  const setH = (h: number) => onChange(Math.max(0, h) * 60 + mins);
  const setM = (m: number) => onChange(hours * 60 + Math.max(0, Math.min(59, m)));

  const presets = [
    { label: "2h", mins: 120 },
    { label: "4h", mins: 240 },
    { label: "6h", mins: 360 },
    { label: "8h", mins: 480 },
    { label: "12h", mins: 720 },
    { label: "24h", mins: 1440 },
  ];

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 bg-[var(--muted)] border border-[var(--border)] rounded-xl px-4 py-2.5 flex-1">
          <Timer size={15} className="text-[#4f6ef7] shrink-0" />
          <input
            type="number" min="0" max="72" value={hours}
            onChange={(e) => setH(Number(e.target.value))}
            className="w-12 bg-transparent text-[var(--foreground)] text-sm font-mono font-bold focus:outline-none text-center"
          />
          <span className="text-[var(--muted-foreground)] text-xs">hrs</span>
          <span className="text-[var(--muted-foreground)]">:</span>
          <input
            type="number" min="0" max="59" value={mins}
            onChange={(e) => setM(Number(e.target.value))}
            className="w-12 bg-transparent text-[var(--foreground)] text-sm font-mono font-bold focus:outline-none text-center"
          />
          <span className="text-[var(--muted-foreground)] text-xs">min</span>
        </div>
      </div>
      {/* Quick presets */}
      <div className="flex flex-wrap gap-2">
        {presets.map((p) => (
          <button
            key={p.label}
            onClick={() => onChange(p.mins)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${value === p.mins ? "bg-[#4f6ef7] text-white border-[#4f6ef7]" : "border-[var(--border)] text-[var(--muted-foreground)] hover:border-[#4f6ef7] hover:text-[#4f6ef7]"}`}
          >
            {p.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function SmartJourney() {
  const [from, setFrom] = useState("Hyderabad");
  const [to, setTo] = useState("Bengaluru");
  const [viaStops, setViaStops] = useState<string[]>([]);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [passengers, setPassengers] = useState(1);
  const [budget, setBudget] = useState(5000);
  const [useTimeLimit, setUseTimeLimit] = useState(false);
  const [timeLimitMins, setTimeLimitMins] = useState(360);
  const [searched, setSearched] = useState(false);
  const navigate = useNavigate();

  const addVia = () => setViaStops((v) => [...v, ""]);
  const removeVia = (i: number) => setViaStops((v) => v.filter((_, idx) => idx !== i));
  const updateVia = (i: number, val: string) => setViaStops((v) => v.map((x, idx) => idx === i ? val : x));
  const swapFromTo = () => { setFrom(to); setTo(from); };

  const handleSearch = () => setSearched(true);

  const allOptions = SMART_JOURNEYS[0].options;

  const ranked = useMemo(() => {
    const limit = useTimeLimit ? timeLimitMins : null;
    return [...allOptions]
      .filter((o) => o.price * passengers <= budget)
      .map((o) => ({ ...o, _mins: parseDuration(o.duration) }))
      .sort((a, b) => {
        if (!limit) return 0;
        const aFits = a._mins <= limit;
        const bFits = b._mins <= limit;
        if (aFits && !bFits) return -1;
        if (!aFits && bFits) return 1;
        // Both fit: prefer shortest that still has budget headroom
        return a._mins - b._mins;
      });
  }, [allOptions, budget, passengers, useTimeLimit, timeLimitMins]);

  const bestIdx = useTimeLimit
    ? ranked.findIndex((o) => (o as any)._mins <= timeLimitMins)
    : 0;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#4f6ef7]/20 to-[#00d4aa]/10 py-16 px-4">
        <div className="max-w-3xl mx-auto text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#4f6ef7]/20 text-[#4f6ef7] text-xs font-semibold mb-4">
            <Zap size={12} /> Signature Feature
          </div>
          <h1 className="font-display font-black text-4xl sm:text-5xl mb-3">GoVeya Smart Journey</h1>
          <p className="text-[var(--muted-foreground)] text-base">
            Tell us your time — we'll find the best way to get there.
          </p>
        </div>

        {/* Search form */}
        <div className="max-w-3xl mx-auto glass rounded-2xl p-6 border border-[var(--border)]">

          {/* Route builder */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-[var(--muted-foreground)] font-medium uppercase tracking-wide">Route</span>
              <button
                onClick={addVia}
                className="flex items-center gap-1 text-xs text-[#4f6ef7] font-semibold hover:underline"
              >
                <Plus size={13} /> Add stop
              </button>
            </div>

            {/* From */}
            <LocationPicker label="From" value={from} onChange={setFrom} exclude={to} />

            {/* Via stops */}
            {viaStops.map((v, i) => (
              <div key={i} className="relative mt-2">
                <div className="absolute left-4 -top-3 w-px h-3 bg-[var(--border)]" />
                <div className="flex gap-2 items-end">
                  <div className="flex-1">
                    <LocationPicker
                      label={`Via stop ${i + 1}`}
                      value={v}
                      onChange={(val) => updateVia(i, val)}
                      exclude={from}
                      placeholder="Add a stop..."
                    />
                  </div>
                  <button
                    onClick={() => removeVia(i)}
                    className="mb-0.5 w-10 h-10 rounded-xl bg-red-400/10 text-red-400 flex items-center justify-center hover:bg-red-400/20 shrink-0"
                  >
                    <X size={15} />
                  </button>
                </div>
              </div>
            ))}

            {/* Swap + To row */}
            <div className="flex items-end gap-2 mt-2">
              <div className="flex-1">
                <LocationPicker label="To" value={to} onChange={setTo} exclude={from} />
              </div>
              <button
                onClick={swapFromTo}
                title="Swap From and To"
                className="mb-0.5 w-10 h-10 rounded-xl glass border border-[var(--border)] flex items-center justify-center hover:bg-[#4f6ef7] hover:text-white hover:border-[#4f6ef7] transition-colors shrink-0"
              >
                <ArrowLeftRight size={15} />
              </button>
            </div>

            {/* Route preview pill */}
            {(from || viaStops.length > 0 || to) && (
              <div className="mt-3 flex items-center gap-1 flex-wrap">
                {[from, ...viaStops.filter(Boolean), to].map((city, i, arr) => (
                  <React.Fragment key={i}>
                    <span className="text-xs font-semibold px-2 py-1 rounded-full bg-[#4f6ef7]/10 text-[#4f6ef7]">{city}</span>
                    {i < arr.length - 1 && <ArrowRight size={12} className="text-[var(--muted-foreground)]" />}
                  </React.Fragment>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Travel Date</label>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
                className="mt-1 w-full px-3 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
            </div>
            <div>
              <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Passengers</label>
              <select value={passengers} onChange={(e) => setPassengers(Number(e.target.value))}
                className="mt-1 w-full px-3 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]">
                {[1,2,3,4,5].map((n) => <option key={n} value={n}>{n} Passenger{n > 1 ? "s" : ""}</option>)}
              </select>
            </div>
          </div>

          {/* Budget slider */}
          <div className="mb-4">
            <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">
              Budget per person: <span className="text-[#4f6ef7] font-mono">₹{budget.toLocaleString()}</span>
            </label>
            <input type="range" min={300} max={10000} step={100} value={budget}
              onChange={(e) => setBudget(Number(e.target.value))}
              className="mt-2 w-full accent-[#4f6ef7]" />
            <div className="flex justify-between text-xs text-[var(--muted-foreground)] mt-0.5">
              <span>₹300</span><span>₹10,000</span>
            </div>
          </div>

          {/* Time limit toggle */}
          <div className="mb-5 rounded-2xl border border-[var(--border)] overflow-hidden">
            <button
              onClick={() => setUseTimeLimit((v) => !v)}
              className={`w-full flex items-center gap-3 px-4 py-3.5 text-sm font-semibold transition-all ${useTimeLimit ? "bg-[#4f6ef7]/10 text-[#4f6ef7]" : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]"}`}
            >
              <Timer size={16} className={useTimeLimit ? "text-[#4f6ef7]" : ""} />
              <span className="flex-1 text-left">I have a time limit</span>
              <div className={`w-10 h-5 rounded-full transition-all relative ${useTimeLimit ? "bg-[#4f6ef7]" : "bg-[var(--muted)]"}`}>
                <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${useTimeLimit ? "left-5" : "left-0.5"}`} />
              </div>
            </button>

            {useTimeLimit && (
              <div className="px-4 pb-4 pt-2 border-t border-[var(--border)] bg-[#4f6ef7]/5">
                <div className="text-xs text-[var(--muted-foreground)] mb-3">
                  How long can your journey take? We'll rank options that fit your window first.
                </div>
                <TimeInput value={timeLimitMins} onChange={setTimeLimitMins} />
                {timeLimitMins > 0 && (
                  <p className="text-xs text-[#4f6ef7] mt-2 font-medium">
                    Limit: {Math.floor(timeLimitMins / 60)}h {timeLimitMins % 60 > 0 ? `${timeLimitMins % 60}m` : ""}
                  </p>
                )}
              </div>
            )}
          </div>

          <button onClick={handleSearch}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-[#4f6ef7] to-[#00d4aa] text-white font-bold text-base hover:opacity-90 flex items-center justify-center gap-2">
            <Zap size={18} /> Find Best Journey
          </button>
        </div>
      </div>

      {/* Results */}
      {searched && (
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="flex items-center justify-between mb-2 flex-wrap gap-3">
            <div>
              <h2 className="font-display font-bold text-2xl">
                {[from, ...viaStops.filter(Boolean), to].join(" → ")}
              </h2>
              <p className="text-sm text-[var(--muted-foreground)]">
                {ranked.length} option{ranked.length !== 1 ? "s" : ""} found · {passengers} passenger{passengers > 1 ? "s" : ""}
                {useTimeLimit && ` · limit ${Math.floor(timeLimitMins / 60)}h${timeLimitMins % 60 > 0 ? ` ${timeLimitMins % 60}m` : ""}`}
              </p>
            </div>
            <div className="text-xs px-3 py-1.5 rounded-full bg-[#4f6ef7]/10 text-[#4f6ef7] font-medium flex items-center gap-1.5">
              {useTimeLimit ? <><Timer size={12} /> Sorted by time fit</> : <>Sorted by recommendation</>}
            </div>
          </div>

          {useTimeLimit && (
            <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-[#4f6ef7]/10 to-[#00d4aa]/10 border border-[#4f6ef7]/20 flex items-start gap-3">
              <Timer size={16} className="text-[#4f6ef7] shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-[#4f6ef7]">
                  Time limit: {Math.floor(timeLimitMins / 60)}h {timeLimitMins % 60 > 0 ? `${timeLimitMins % 60}m` : ""}
                </p>
                <p className="text-xs text-[var(--muted-foreground)] mt-0.5">
                  Options that fit are shown first, highlighted with a progress bar showing how much of your time they use.
                </p>
              </div>
            </div>
          )}

          <div className="flex flex-col gap-6">
            {ranked.length === 0 && (
              <div className="glass rounded-2xl p-12 text-center border border-[var(--border)]">
                <div className="text-4xl mb-3">💸</div>
                <div className="font-display font-bold text-lg mb-1">No options within budget</div>
                <div className="text-sm text-[var(--muted-foreground)]">Try increasing your budget or adjusting your time limit</div>
              </div>
            )}
            {ranked.map((option, i) => (
              <JourneyCard
                key={option.label}
                option={option}
                timeLimitMins={useTimeLimit ? timeLimitMins : null}
                budget={budget}
                passengers={passengers}
                isBest={i === bestIdx && useTimeLimit}
                onSelect={() => navigate(`/seat-selection?mode=${option.type === "combined" ? "bus" : option.type}&id=${option.type === "flight" ? "6E202" : option.type === "train" ? "12163" : "BUS001"}`)}
              />
            ))}
          </div>

          <div className="mt-6 p-4 rounded-xl bg-[var(--muted)] border border-[var(--border)]">
            <p className="text-xs text-[var(--muted-foreground)] text-center">
              ⚠️ This is a prototype using sample data. Journey options and risk scores are illustrative only.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
