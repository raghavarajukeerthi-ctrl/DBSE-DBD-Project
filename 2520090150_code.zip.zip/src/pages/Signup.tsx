import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, User, Phone } from "lucide-react";

export default function Signup() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex items-center justify-center px-4 hero-gradient">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#4f6ef7] to-[#00d4aa] flex items-center justify-center">
              <span className="text-white font-bold font-display">G</span>
            </div>
            <span className="font-display font-black text-2xl">GoVeya</span>
          </div>
          <h1 className="font-display font-bold text-2xl mb-1">Create your account</h1>
          <p className="text-[var(--muted-foreground)] text-sm">Start booking smarter today</p>
        </div>
        <div className="glass rounded-2xl border border-[var(--border)] p-8">
          <div className="flex flex-col gap-4">
            {[
              { icon: <User size={15} />, placeholder: "Full name", type: "text" },
              { icon: <Mail size={15} />, placeholder: "Email address", type: "email" },
              { icon: <Phone size={15} />, placeholder: "Phone number", type: "tel" },
              { icon: <Lock size={15} />, placeholder: "Password", type: "password" },
            ].map((f, i) => (
              <div key={i} className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]">{f.icon}</div>
                <input type={f.type} placeholder={f.placeholder}
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
              </div>
            ))}
            <button onClick={() => navigate("/dashboard")}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#4f6ef7] to-[#00d4aa] text-white font-bold text-sm hover:opacity-90 mt-2">
              Create Account
            </button>
          </div>
          <p className="text-center text-sm text-[var(--muted-foreground)] mt-5">
            Already have an account?{" "}
            <Link to="/login" className="text-[#4f6ef7] font-medium hover:underline">Sign In</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
