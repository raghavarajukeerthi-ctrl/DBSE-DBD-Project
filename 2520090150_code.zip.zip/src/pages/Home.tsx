import { useState } from "react";
import { useNavigate } from "react-router-dom";

const MODES = [
  { icon: "🚌", label: "Bus",           path: "/search/bus",    rgb: "245,158,11", hex: "#f59e0b" },
  { icon: "🚆", label: "Train",         path: "/search/train",  rgb: "0,212,170",  hex: "#00d4aa" },
  { icon: "✈️", label: "Flight",        path: "/search/flight", rgb: "79,110,247", hex: "#4f6ef7" },
  { icon: "⚡", label: "Smart Journey", path: "/smart-journey", rgb: "168,85,247", hex: "#a855f7" },
];

function ModeButton({ mode }: { mode: typeof MODES[0] }) {
  const [hovered, setHovered] = useState(false);
  const navigate = useNavigate();
  return (
    <button
      onClick={() => navigate(mode.path)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="flex flex-col items-center gap-3 py-7 px-4 rounded-2xl transition-all duration-200 w-full"
      style={{
        background: hovered ? `rgba(${mode.rgb},0.1)` : "rgba(255,255,255,0.03)",
        border: `1px solid ${hovered ? mode.hex : "rgba(255,255,255,0.08)"}`,
        boxShadow: hovered ? `0 0 28px rgba(${mode.rgb},0.28)` : "none",
        transform: hovered ? "translateY(-5px)" : "translateY(0)",
      }}
    >
      <span className="text-4xl" style={{ filter: hovered ? `drop-shadow(0 0 10px rgba(${mode.rgb},0.7))` : "none" }}>
        {mode.icon}
      </span>
      <span className="text-sm font-semibold leading-tight text-center" style={{ color: hovered ? mode.hex : "#6b7280" }}>
        {mode.label}
      </span>
    </button>
  );
}

export default function Home() {
  return (
    <div className="min-h-[calc(100vh-64px)] hero-gradient flex flex-col items-center justify-center px-4 relative overflow-hidden">
      {/* Ambient orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(79,110,247,0.1) 0%, transparent 70%)", filter: "blur(60px)" }} />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(0,212,170,0.08) 0%, transparent 70%)", filter: "blur(60px)" }} />

      <div className="relative z-10 flex flex-col items-center gap-10 w-full max-w-xl text-center">
        {/* Heading */}
        <div>
          <h1 className="font-display font-black leading-[1.05] mb-4" style={{ fontSize: "clamp(40px, 8vw, 72px)", letterSpacing: "-0.02em" }}>
            <span className="gradient-text">One Journey.</span>
            <br />Every Way.
          </h1>
          <p className="text-[var(--muted-foreground)] text-base sm:text-lg leading-relaxed">
            Search, compare and book buses, trains and flights from one intelligent travel platform.
          </p>
        </div>

        {/* 4 mode buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full">
          {MODES.map((m) => <ModeButton key={m.label} mode={m} />)}
        </div>
      </div>
    </div>
  );
}
