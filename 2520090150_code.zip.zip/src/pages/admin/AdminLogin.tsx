import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Mail, Lock, Shield } from "lucide-react";

export default function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");

  const VALID_EMAILS = ["jaswanthtetala@gmail.com", "keerthivarma1608@gmail.com"];
  const VALID_PASSWORD = "JK@1605";

  const handleLogin = () => {
    if (VALID_EMAILS.includes(email) && pass === VALID_PASSWORD) {
      navigate("/admin/dashboard");
    } else {
      setError("Invalid email or password.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-[var(--background)]">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#4f6ef7] to-[#00d4aa] flex items-center justify-center mx-auto mb-4">
            <Shield size={24} className="text-white" />
          </div>
          <h1 className="font-display font-black text-2xl mb-1">GoVeya Admin</h1>
          <p className="text-[var(--muted-foreground)] text-sm">Secure admin access only</p>
        </div>
        <div className="glass rounded-2xl border border-[var(--border)] p-8">
          {error && <div className="mb-4 p-3 rounded-xl bg-red-400/10 border border-red-400/20 text-red-400 text-xs">{error}</div>}
          <div className="flex flex-col gap-4">
            <div className="relative">
              <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
              <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="Admin email"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
            </div>
            <div className="relative">
              <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
              <input value={pass} onChange={(e) => setPass(e.target.value)} type="password" placeholder="Password"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
            </div>
            <button onClick={handleLogin}
              className="w-full py-3 rounded-xl bg-[#4f6ef7] text-white font-bold text-sm hover:bg-[#3b5bdb]">
              Admin Login
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
