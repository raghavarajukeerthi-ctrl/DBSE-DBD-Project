import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend
} from "recharts";
import {
  LayoutDashboard, CreditCard, BookOpen, Bus, Train, Plane,
  LogOut, TrendingUp, TrendingDown, Users, IndianRupee, Search, Filter, ChevronDown, Check, X, Clock
} from "lucide-react";
import { ADMIN_STATS, ADMIN_BOOKINGS, MONTHLY_DATA, ROUTE_DATA, TRANSPORT_DATA } from "../../data";

function StatCard({ label, value, sub, trend, icon }: { label: string; value: string | number; sub?: string; trend?: "up" | "down"; icon: React.ReactNode }) {
  return (
    <div className="glass rounded-2xl border border-[var(--border)] p-5">
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-xl bg-[#4f6ef7]/10 flex items-center justify-center text-[#4f6ef7]">{icon}</div>
        {trend && (
          <div className={`flex items-center gap-1 text-xs font-medium ${trend === "up" ? "text-[#00d4aa]" : "text-red-400"}`}>
            {trend === "up" ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {trend === "up" ? "+12%" : "-3%"}
          </div>
        )}
      </div>
      <div className="font-display font-black text-2xl mb-0.5">{typeof value === "number" ? value.toLocaleString() : value}</div>
      <div className="text-[var(--muted-foreground)] text-xs">{label}</div>
      {sub && <div className="text-xs text-[#00d4aa] mt-1">{sub}</div>}
    </div>
  );
}

const STATUS_BADGE: Record<string, string> = {
  Successful: "text-[#00d4aa] bg-[#00d4aa]/10",
  Pending: "text-amber-400 bg-amber-400/10",
  Failed: "text-red-400 bg-red-400/10",
  Refunded: "text-[#4f6ef7] bg-[#4f6ef7]/10",
};

type AdminSection = "overview" | "payments" | "bookings" | "transport";

export default function AdminDashboard() {
  const [section, setSection] = useState<AdminSection>("overview");
  const [search, setSearch] = useState("");
  const navigate = useNavigate();

  const filteredPayments = ADMIN_BOOKINGS.filter((p) =>
    [p.paymentId, p.bookingId, p.passenger, p.txnId].some((v) => v.toLowerCase().includes(search.toLowerCase()))
  );

  const sideItems = [
    { id: "overview", icon: <LayoutDashboard size={16} />, label: "Overview" },
    { id: "payments", icon: <CreditCard size={16} />, label: "Payment Management" },
    { id: "bookings", icon: <BookOpen size={16} />, label: "Booking Management" },
    { id: "transport", icon: <Bus size={16} />, label: "Transport Management" },
  ];

  return (
    <div className="min-h-screen flex bg-[var(--background)]">
      {/* Admin sidebar */}
      <aside className="w-56 shrink-0 bg-[var(--card)] border-r border-[var(--border)] flex flex-col hidden md:flex">
        <div className="p-5 border-b border-[var(--border)]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4f6ef7] to-[#00d4aa] flex items-center justify-center">
              <span className="text-white font-bold text-sm font-display">G</span>
            </div>
            <div>
              <div className="font-display font-bold text-sm">GoVeya</div>
              <div className="text-[10px] text-[var(--muted-foreground)]">Admin Panel</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-3 flex flex-col gap-1">
          {sideItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setSection(item.id as AdminSection)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${section === item.id ? "bg-[#4f6ef7]/10 text-[#4f6ef7]" : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]"}`}
            >
              {item.icon} {item.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-[var(--border)]">
          <button onClick={() => navigate("/")} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-[var(--muted-foreground)] hover:text-[var(--foreground)] w-full">
            <LogOut size={16} /> Exit Admin
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top bar */}
        <div className="bg-[var(--card)] border-b border-[var(--border)] px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="font-display font-bold text-lg">
              {sideItems.find((s) => s.id === section)?.label || "Admin Dashboard"}
            </h1>
            <p className="text-xs text-[var(--muted-foreground)]">GoVeya Admin Panel · Demo Mode</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#4f6ef7]/20 flex items-center justify-center text-[#4f6ef7] text-sm font-bold font-display">A</div>
            <span className="text-sm font-medium hidden sm:block">Admin</span>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-6">
          {/* Mobile section selector */}
          <div className="flex gap-2 flex-wrap mb-6 md:hidden">
            {sideItems.map((item) => (
              <button key={item.id} onClick={() => setSection(item.id as AdminSection)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border ${section === item.id ? "bg-[#4f6ef7] text-white border-[#4f6ef7]" : "border-[var(--border)] text-[var(--muted-foreground)]"}`}>
                {item.icon} {item.label}
              </button>
            ))}
          </div>

          {/* OVERVIEW */}
          {section === "overview" && (
            <div className="flex flex-col gap-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <StatCard label="Total Bookings" value={ADMIN_STATS.totalBookings} trend="up" icon={<BookOpen size={18} />} />
                <StatCard label="Today's Bookings" value={ADMIN_STATS.todayBookings} icon={<Clock size={18} />} />
                <StatCard label="Successful Payments" value={ADMIN_STATS.successfulPayments} trend="up" icon={<Check size={18} />} />
                <StatCard label="Total Revenue" value={`₹${(ADMIN_STATS.totalRevenue / 100000).toFixed(1)}L`} trend="up" icon={<IndianRupee size={18} />} />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <StatCard label="Pending Payments" value={ADMIN_STATS.pendingPayments} icon={<Clock size={18} />} />
                <StatCard label="Failed Payments" value={ADMIN_STATS.failedPayments} trend="down" icon={<X size={18} />} />
                <StatCard label="Cancelled Bookings" value={ADMIN_STATS.cancelledBookings} icon={<X size={18} />} />
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 glass rounded-2xl border border-[var(--border)] p-5">
                  <h3 className="font-display font-bold text-sm mb-4">Monthly Bookings & Revenue</h3>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={MONTHLY_DATA} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                      <XAxis dataKey="month" tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", color: "var(--foreground)", fontSize: "12px" }}
                        cursor={{ fill: "rgba(79,110,247,0.08)" }}
                      />
                      <Bar dataKey="bookings" fill="#4f6ef7" radius={[6, 6, 0, 0]} name="Bookings" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="glass rounded-2xl border border-[var(--border)] p-5">
                  <h3 className="font-display font-bold text-sm mb-4">Booking by Mode</h3>
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie data={TRANSPORT_DATA} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, value }) => `${value}%`} labelLine={false}>
                        {TRANSPORT_DATA.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                      </Pie>
                      <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", color: "var(--muted-foreground)" }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Popular routes */}
              <div className="glass rounded-2xl border border-[var(--border)] p-5">
                <h3 className="font-display font-bold text-sm mb-4">Most Popular Routes</h3>
                <div className="flex flex-col gap-3">
                  {ROUTE_DATA.map((r) => (
                    <div key={r.route} className="flex items-center gap-3">
                      <span className="font-mono text-sm w-24 shrink-0">{r.route}</span>
                      <div className="flex-1 h-2 rounded-full bg-[var(--muted)] overflow-hidden">
                        <div className="h-full rounded-full bg-gradient-to-r from-[#4f6ef7] to-[#00d4aa]" style={{ width: `${(r.bookings / 350) * 100}%` }} />
                      </div>
                      <span className="font-mono text-xs text-[var(--muted-foreground)] w-12 text-right">{r.bookings}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* PAYMENTS */}
          {section === "payments" && (
            <div>
              <div className="flex flex-col sm:flex-row gap-3 mb-5">
                <div className="relative flex-1">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                  <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by ID, passenger, transaction..."
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
                </div>
                <select className="px-3 py-2.5 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-sm focus:outline-none focus:border-[#4f6ef7]">
                  <option>All Status</option>
                  <option>Successful</option>
                  <option>Pending</option>
                  <option>Failed</option>
                  <option>Refunded</option>
                </select>
              </div>
              <div className="glass rounded-2xl border border-[var(--border)] overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[var(--border)]">
                        {["Payment ID", "Booking ID", "Passenger", "Amount", "Method", "Status", "Date", "Transaction ID"].map((h) => (
                          <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wide whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredPayments.map((p) => (
                        <tr key={p.paymentId} className="border-b border-[var(--border)] hover:bg-[var(--muted)]/30 transition-colors">
                          <td className="px-4 py-3 font-mono text-xs text-[#4f6ef7]">{p.paymentId}</td>
                          <td className="px-4 py-3 font-mono text-xs">{p.bookingId}</td>
                          <td className="px-4 py-3 font-medium">{p.passenger}</td>
                          <td className="px-4 py-3 font-mono font-bold text-[#00d4aa]">₹{p.amount.toLocaleString()}</td>
                          <td className="px-4 py-3 text-xs">{p.method}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_BADGE[p.status] || ""}`}>{p.status}</span>
                          </td>
                          <td className="px-4 py-3 text-xs text-[var(--muted-foreground)] whitespace-nowrap">{p.date}</td>
                          <td className="px-4 py-3 font-mono text-xs text-[var(--muted-foreground)]">{p.txnId}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* BOOKINGS */}
          {section === "bookings" && (
            <div>
              <div className="flex flex-col sm:flex-row gap-3 mb-5">
                <div className="relative flex-1">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                  <input placeholder="Search bookings..." className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-sm focus:outline-none focus:border-[#4f6ef7]" />
                </div>
                <select className="px-3 py-2.5 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-sm focus:outline-none focus:border-[#4f6ef7]">
                  <option>All Types</option>
                  <option>Flight</option>
                  <option>Train</option>
                  <option>Bus</option>
                </select>
              </div>
              <div className="glass rounded-2xl border border-[var(--border)] overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[var(--border)]">
                        {["Booking ID", "Passenger", "Route", "Mode", "Date", "Seat", "Amount", "Status", "Actions"].map((h) => (
                          <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wide whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {ADMIN_BOOKINGS.map((p) => (
                        <tr key={p.paymentId} className="border-b border-[var(--border)] hover:bg-[var(--muted)]/30">
                          <td className="px-4 py-3 font-mono text-xs text-[#4f6ef7]">{p.bookingId}</td>
                          <td className="px-4 py-3 font-medium">{p.passenger}</td>
                          <td className="px-4 py-3 text-xs">HYD → BLR</td>
                          <td className="px-4 py-3 text-xs">Flight</td>
                          <td className="px-4 py-3 text-xs text-[var(--muted-foreground)]">{p.date}</td>
                          <td className="px-4 py-3 font-mono text-xs">12A</td>
                          <td className="px-4 py-3 font-mono font-bold text-[#00d4aa]">₹{p.amount.toLocaleString()}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_BADGE[p.status] || ""}`}>{p.status}</span>
                          </td>
                          <td className="px-4 py-3">
                            <button className="text-xs text-[#4f6ef7] hover:underline">View</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TRANSPORT */}
          {section === "transport" && (
            <div className="flex flex-col gap-6">
              {[
                { type: "Bus", icon: "🚌", items: ["Mumbai Express – MUM→PUN – 09:00 – ₹299", "VRL Travels – HYD→BLR – 22:30 – ₹649", "IntrCity SmartBus – HYD→BLR – 21:00 – ₹799"] },
                { type: "Train", icon: "🚆", items: ["12163 Chennai Express – HYD→BLR – 06:10 – ₹545", "12785 KCG Express – HYD→BLR – 22:15 – ₹725", "12001 Shatabdi – DEL→MUM – 06:00 – ₹1,295"] },
                { type: "Flight", icon: "✈️", items: ["IndiGo 6E202 – HYD→BLR – 07:00 – ₹2,499", "Air India AI444 – HYD→BLR – 10:30 – ₹3,299", "Vistara UK945 – MUM→DEL – 09:00 – ₹4,599"] },
              ].map((cat) => (
                <div key={cat.type} className="glass rounded-2xl border border-[var(--border)] p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-display font-bold text-base flex items-center gap-2">{cat.icon} {cat.type} Management</h3>
                    <button className="px-3 py-1.5 rounded-lg bg-[#4f6ef7]/10 text-[#4f6ef7] text-xs font-semibold hover:bg-[#4f6ef7]/20">
                      + Add {cat.type}
                    </button>
                  </div>
                  <div className="flex flex-col gap-2">
                    {cat.items.map((item) => (
                      <div key={item} className="flex items-center justify-between p-3 rounded-xl bg-[var(--muted)] border border-[var(--border)]">
                        <span className="text-sm">{item}</span>
                        <div className="flex gap-2">
                          <button className="text-xs text-[#4f6ef7] hover:underline">Edit</button>
                          <button className="text-xs text-red-400 hover:underline">Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
