import { useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { User, Phone, Mail, ArrowRight } from "lucide-react";

interface Passenger {
  name: string;
  age: string;
  gender: string;
  phone: string;
  email: string;
}

const blank = (): Passenger => ({ name: "", age: "", gender: "male", phone: "", email: "" });

export default function PassengerDetails() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const mode = params.get("mode") || "flight";
  const seats = (params.get("seats") || "12A").split(",");
  const fare = Number(params.get("fare") || 2499);

  const [passengers, setPassengers] = useState<Passenger[]>(seats.map(() => blank()));

  const update = (i: number, field: keyof Passenger, val: string) => {
    setPassengers((p) => p.map((x, idx) => idx === i ? { ...x, [field]: val } : x));
  };

  const valid = passengers.every((p) => p.name && p.age && p.phone && p.email);

  const handleContinue = () => {
    const pData = encodeURIComponent(JSON.stringify(passengers));
    navigate(`/payment?mode=${mode}&seats=${seats.join(",")}&fare=${fare}&name=${encodeURIComponent(passengers[0].name)}&passengers=${pData}`);
  };

  return (
    <div className="min-h-screen py-10 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="font-display font-black text-3xl mb-1">Passenger Details</h1>
          <p className="text-[var(--muted-foreground)] text-sm">Fill in details for all passengers</p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 flex flex-col gap-6">
            {passengers.map((p, i) => (
              <div key={i} className="glass rounded-2xl border border-[var(--border)] p-6">
                <h3 className="font-display font-bold text-base mb-5 flex items-center gap-2">
                  <User size={16} className="text-[#4f6ef7]" />
                  Passenger {i + 1} · Seat {seats[i]}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Full Name *</label>
                    <input
                      value={p.name} onChange={(e) => update(i, "name", e.target.value)}
                      placeholder="As on government ID"
                      className="mt-1 w-full px-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Age *</label>
                    <input
                      value={p.age} onChange={(e) => update(i, "age", e.target.value)}
                      type="number" min="1" max="120" placeholder="25"
                      className="mt-1 w-full px-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Gender *</label>
                    <select
                      value={p.gender} onChange={(e) => update(i, "gender", e.target.value)}
                      className="mt-1 w-full px-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]"
                    >
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                      <option value="prefer_not">Prefer not to say</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Phone *</label>
                    <div className="mt-1 relative">
                      <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                      <input
                        value={p.phone} onChange={(e) => update(i, "phone", e.target.value)}
                        placeholder="+91 98765 43210" type="tel"
                        className="w-full pl-9 pr-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-[var(--muted-foreground)] uppercase tracking-wide font-medium">Email *</label>
                    <div className="mt-1 relative">
                      <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                      <input
                        value={p.email} onChange={(e) => update(i, "email", e.target.value)}
                        placeholder="you@example.com" type="email"
                        className="w-full pl-9 pr-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm focus:outline-none focus:border-[#4f6ef7]"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="lg:w-72 shrink-0">
            <div className="glass rounded-2xl border border-[var(--border)] p-6 sticky top-24">
              <h3 className="font-display font-bold text-base mb-4">Booking Summary</h3>
              <div className="flex flex-col gap-3 mb-5 text-sm">
                <div className="flex justify-between">
                  <span className="text-[var(--muted-foreground)]">Route</span>
                  <span className="font-medium">HYD → BLR</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--muted-foreground)]">Mode</span>
                  <span className="font-medium capitalize">{mode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--muted-foreground)]">Seats</span>
                  <span className="font-mono text-[#4f6ef7]">{seats.join(", ")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--muted-foreground)]">Base fare</span>
                  <span className="font-mono">₹{(fare * 0.85).toFixed(0)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--muted-foreground)]">Taxes & fees</span>
                  <span className="font-mono">₹{(fare * 0.15).toFixed(0)}</span>
                </div>
                <div className="border-t border-[var(--border)] pt-3 flex justify-between">
                  <span className="font-bold">Total</span>
                  <span className="font-mono font-black text-xl text-[#00d4aa]">₹{fare.toLocaleString()}</span>
                </div>
              </div>
              <button
                onClick={handleContinue}
                disabled={!valid}
                className="w-full py-3 rounded-xl bg-[#4f6ef7] text-white font-bold text-sm hover:bg-[#3b5bdb] disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                Continue to Payment <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
