# MASTER PROMPT — GOVЕYA

Create a complete, modern, premium travel-booking website called **GoVeya**.

### Brand

**Name:** GoVeya
**Tagline:** **One Journey. Every Way.**

GoVeya is a multi-modal travel platform where users can search, compare, and book **bus, train, and flight tickets** from one website.

The website should look like a real modern travel-tech startup rather than a basic college project.

---

# 1. UNIQUE FEATURE — GoVeya Smart Journey

Create a signature feature called:

## **GoVeya Smart Journey**

Instead of forcing users to book only one type of transport, GoVeya should help users build an entire journey.

Example:

**Hyderabad → Bengaluru**

The system can present:

* ✈️ Flight
* 🚆 Train
* 🚌 Bus
* 🔄 Combined journey options

For each option display:

* Total price
* Total travel time
* Departure
* Arrival
* Number of transfers
* Connection/buffer time
* Seat availability
* Comfort level
* Estimated journey risk
* Environmental impact estimate

Allow users to compare different journeys side by side.

---

# 2. UNIQUE FEATURE — GoVeya Backup Journey

Add another innovative feature called:

## **GoVeya Backup Journey**

For multi-segment trips, calculate whether the user has enough time between connections.

Example:

Train arrives at 5:00 PM.

Next bus leaves at 5:40 PM.

The system should display:

**40-minute connection**

and show:

**Connection Risk: Medium**

If the connection time is too short, display:

> “Your connection may be difficult. View backup options.”

Add a:

### **Find Backup Journey**

button.

The system should then display alternative bus, train, or flight options from the sample database.

This should be presented as a prototype feature using sample data. Do not claim guaranteed real-time delay prediction or automatic rebooking.

---

# 3. HOME PAGE

Create a beautiful landing page containing:

### Header

* GoVeya logo
* Home
* Bus
* Train
* Flight
* Smart Journey
* My Bookings
* Login
* Sign Up

### Hero Section

Large heading:

**One Journey. Every Way.**

Subheading:

**Search, compare and book buses, trains and flights from one intelligent travel platform.**

Add a large booking/search panel.

Tabs:

* Bus
* Train
* Flight
* Smart Journey

Search fields:

* From
* To
* Departure date
* Return date
* Passengers

Buttons:

**Search Tickets**

and

**Plan Smart Journey**

---

# 4. SMART JOURNEY PAGE

Create a dedicated Smart Journey page.

Inputs:

* Starting location
* Destination
* Travel date
* Number of passengers
* Budget
* Maximum travel duration
* Preferred transport

Allow:

* Bus
* Train
* Flight
* Any

After searching, show recommended journey cards.

Each card should display:

**Journey Option 1**

Hyderabad → Bengaluru

✈️ Flight

Departure: 08:30 AM
Arrival: 09:45 AM
Duration: 1h 15m
Price: ₹3,499

Connection Risk: Low

[Select Journey]

---

# 5. SEARCH RESULTS

Create professional result cards.

Each result should contain:

* Operator
* Transport type
* Departure
* Arrival
* Duration
* Price
* Available seats
* Rating
* Amenities
* Select button

Filters:

* Price
* Departure time
* Arrival time
* Duration
* Transport type
* Stops
* Amenities

Sorting:

* Cheapest
* Fastest
* Best rated
* Recommended

---

# 6. SEAT SELECTION

Create separate seat-selection interfaces for:

### Bus

Show a realistic bus seat layout.

### Train

Show coach/berth selection.

### Flight

Show an aircraft seat layout.

Seat states:

* Available
* Selected
* Occupied

Show:

**Selected Seats**

**Total Fare**

**Continue**

---

# 7. PASSENGER DETAILS

Collect:

* Full name
* Age
* Gender
* Phone number
* Email

Show a booking summary on the right.

Do not collect unnecessary sensitive information.

---

# 8. PAYMENT SYSTEM

Create a professional payment page.

Display:

### Booking Summary

* Route
* Transport
* Date
* Passenger count
* Seat number
* Base fare
* Taxes
* Discount
* Final amount

Payment methods:

* UPI
* QR Code
* Demo Payment

---

# 9. QR PAYMENT FLOW

Implement the following safe payment workflow:

### Step 1

User clicks:

**Pay Now**

### Step 2

Create a booking with status:

**Pending Payment**

### Step 3

Display a UPI QR code.

### Step 4

User scans the QR code using their UPI application and authorizes the payment.

### Step 5

Payment gateway verifies the transaction.

### Step 6

The backend receives payment confirmation through a webhook.

### Step 7

Update payment status:

**Payment Successful**

### Step 8

Update booking:

**Confirmed**

### Step 9

Automatically generate the ticket.

### Step 10

Display:

**Payment Successful ✓**

**Booking Confirmed ✓**

Important:

Do NOT implement a system where merely displaying a QR code automatically transfers money.

For the college demonstration, include a clearly labelled:

**Demo Payment**

option that simulates successful payment.

Never store:

* UPI PIN
* Card CVV
* Full card details
* Banking passwords

---

# 10. TICKET GENERATION

After successful payment generate a digital ticket.

Ticket should contain:

* GoVeya logo
* Passenger name
* Booking ID
* Ticket number
* Transport type
* Operator
* From
* To
* Date
* Departure
* Arrival
* Seat number
* Amount paid
* Payment status
* QR/barcode for ticket verification

Add:

**Download Ticket**

button.

---

# 11. USER DASHBOARD

Create:

## My GoVeya

Sections:

* Profile
* Upcoming trips
* Previous trips
* Cancelled trips
* Saved journeys
* Payment history
* Notifications

Each booking should have:

**View Ticket**

**Download Ticket**

**Cancel Booking**

---

# 12. ADMIN LOGIN

Create a separate secure admin login.

URL/page:

**Admin Login**

Fields:

* Admin email
* Password

After login show:

# GoVeya Admin Dashboard

Dashboard cards:

* Total Bookings
* Today's Bookings
* Successful Payments
* Pending Payments
* Failed Payments
* Cancelled Bookings
* Total Revenue

---

# 13. ADMIN PAYMENT MANAGEMENT

Create a dedicated:

## Payment Management

table.

Columns:

| Payment ID | Booking ID | Passenger | Amount | Method | Status | Date | Transaction ID |
| ---------- | ---------- | --------- | ------ | ------ | ------ | ---- | -------------- |

Payment statuses:

* Successful
* Pending
* Failed
* Refunded

Add:

* Search
* Date filter
* Transport filter
* Payment status filter
* Export report

Admin should be able to open a payment and view its complete transaction information.

---

# 14. ADMIN BOOKING MANAGEMENT

Admin should be able to:

* View bookings
* Search bookings
* Filter bookings
* View passenger details
* View ticket information
* Change booking status
* Process cancellations/refunds in the prototype
* View payment status

---

# 15. TRANSPORT MANAGEMENT

Admin can manage:

### Bus

* Add bus
* Edit bus
* Delete bus
* Price
* Seats
* Route
* Timing

### Train

* Add train
* Edit train
* Delete train
* Coaches
* Seats
* Route
* Timing

### Flight

* Add flight
* Edit flight
* Delete flight
* Seats
* Route
* Timing
* Price

Use sample data for the project.

---

# 16. DATABASE

Use MySQL.

Create tables:

* users
* admins
* buses
* trains
* flights
* routes
* seats
* passengers
* bookings
* payments
* journey_plans
* journey_segments
* notifications

Use proper:

* Primary keys
* Foreign keys
* Unique constraints
* Indexes
* Relationships

Payment records must be connected to bookings.

---

# 17. PAYMENT DATABASE

The payments table should contain fields such as:

* payment_id
* booking_id
* transaction_id
* amount
* payment_method
* payment_status
* payment_date
* gateway_reference

Never store sensitive payment credentials.

---

# 18. NOTIFICATION SYSTEM

After successful booking show:

**Booking Confirmed!**

Provide notification examples:

* Payment successful
* Ticket confirmed
* Journey reminder
* Booking cancelled
* Refund initiated

---

# 19. DESIGN

Use a premium modern travel-tech design.

Style:

* Minimal
* Modern
* Professional
* Futuristic
* Responsive
* Mobile-friendly

Include:

* Smooth animations
* Hover effects
* Modern cards
* Beautiful icons
* Clean typography
* Attractive travel imagery
* Glassmorphism elements where appropriate
* Dark/light mode

Do not overcrowd the interface.

---

# 20. TECH STACK

Use:

### Frontend

* React
* TypeScript
* Tailwind CSS

### Backend

* Node.js
* Express.js

### Database

* MySQL

### Authentication

Use secure authentication with hashed passwords and protected admin routes.

### Payment

Structure the backend so a real payment gateway can be connected later.

For the project demonstration, provide Demo Payment functionality.

---

# 21. RESPONSIVE DESIGN

The website must work properly on:

* Desktop
* Laptop
* Tablet
* Mobile

The mobile navigation should use a responsive menu.

---

# 22. SAMPLE DATA

Add realistic sample data for:

### Cities

* Hyderabad
* Bengaluru
* Chennai
* Mumbai
* Delhi
* Pune
* Vijayawada
* Visakhapatnam

Add sample buses, trains, flights, routes, prices and seats.

Clearly treat sample transport availability as demonstration data unless connected to real provider APIs.

---

# 23. SECURITY

Implement:

* Password hashing
* Protected admin routes
* Input validation
* Authentication
* Authorization
* Secure API endpoints
* Payment verification
* Webhook verification
* No storage of sensitive payment credentials

---

# 24. ADMIN ANALYTICS

Create charts showing:

* Daily bookings
* Monthly revenue
* Bus bookings
* Train bookings
* Flight bookings
* Successful vs failed payments
* Most popular routes

---

# 25. BRANDING

Use:

# GoVeya

## One Journey. Every Way.

Create a simple modern logo using a combination of:

**G + route/path + travel symbol**

The branding should feel similar to a modern technology startup.

---

# 26. PROJECT PRESENTATION FEATURES

Include an “About Project” section explaining:

### Problem

Travelers often need different websites/apps for buses, trains and flights. Comparing complete journeys across multiple transportation types can be difficult.

### Solution

GoVeya combines multiple transportation options into one platform and provides intelligent journey comparison and backup planning.

### Innovation

**GoVeya Smart Journey + GoVeya Backup Journey**

These features help users compare complete journeys instead of simply searching for individual tickets.

---

# 27. FINAL REQUIREMENTS

Generate the complete working project.

Provide:

1. Complete frontend
2. Complete backend
3. MySQL database
4. SQL schema
5. Sample database records
6. User authentication
7. Admin authentication
8. Booking system
9. Seat selection
10. Payment system
11. QR payment interface
12. Demo payment
13. Payment verification architecture
14. Admin payment dashboard
15. Ticket generation
16. Booking history
17. Smart Journey
18. Backup Journey
19. Analytics dashboard
20. Responsive design
21. README
22. Installation instructions
23. API documentation
24. Project abstract
25. Problem statement
26. Future scope
27. Viva questions and answers

Make every page connected and functional.

Do not create placeholder buttons that do nothing.

Where real external APIs are unavailable, use realistic sample data and clearly separate demo functionality from production functionality.

The final website should feel like a **real travel-tech startup product**, while remaining simple enough to demonstrate and explain during a college project review.

# FINAL BRAND

**GoVeya**

### **One Journey. Every Way.**
