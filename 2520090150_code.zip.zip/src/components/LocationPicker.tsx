import { useState, useRef, useEffect } from "react";
import { MapPin, Search, X } from "lucide-react";
import { CITIES } from "../data";

interface City { name: string; country: string; code: string; }

export default function LocationPicker({
  label,
  value,
  onChange,
  exclude,
  placeholder = "Select city",
}: {
  label?: string;
  value: string;
  onChange: (v: string) => void;
  exclude?: string;
  placeholder?: string;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const filtered = CITIES.filter(
    (c) =>
      c.name !== exclude &&
      (c.name.toLowerCase().includes(query.toLowerCase()) ||
        c.country.toLowerCase().includes(query.toLowerCase()) ||
        c.code.toLowerCase().includes(query.toLowerCase()))
  );

  const indiaGroup = filtered.filter((c) => c.country === "India");

  // Group international by region
  const regionMap: Record<string, string[]> = {
    "South Asia": ["Sri Lanka", "Nepal", "Bangladesh", "Bhutan", "Maldives", "Pakistan"],
    "Middle East": ["UAE", "Oman", "Qatar", "Saudi Arabia", "Kuwait", "Bahrain", "Jordan", "Lebanon", "Israel", "Turkey", "Iran"],
    "Southeast Asia": ["Singapore", "Malaysia", "Thailand", "Indonesia", "Philippines", "Vietnam", "Myanmar", "Cambodia", "Laos", "Brunei"],
    "East Asia": ["Japan", "China", "South Korea", "Taiwan", "Mongolia"],
    "Central Asia": ["Uzbekistan", "Kazakhstan", "Kyrgyzstan", "Tajikistan", "Turkmenistan", "Afghanistan"],
    "Europe": ["UK", "France", "Germany", "Netherlands", "Belgium", "Switzerland", "Italy", "Spain", "Austria", "Czech Republic", "Hungary", "Poland", "Sweden", "Norway", "Denmark", "Finland", "Greece", "Portugal", "Ireland", "Iceland", "Russia", "Romania", "Bulgaria", "Serbia", "Croatia", "Ukraine", "Malta"],
    "Africa": ["Egypt", "Kenya", "South Africa", "Nigeria", "Ghana", "Ethiopia", "Tanzania", "Morocco", "Tunisia", "Uganda", "Rwanda", "Senegal", "Mauritius"],
    "Americas": ["USA", "Canada", "Mexico", "Brazil", "Argentina", "Colombia", "Peru", "Chile"],
    "Oceania": ["Australia", "New Zealand", "Fiji"],
  };

  const getRegion = (country: string) => Object.entries(regionMap).find(([, countries]) => countries.includes(country))?.[0] || "Other";

  const intlByRegion = filtered
    .filter((c) => c.country !== "India")
    .reduce<Record<string, typeof filtered>>((acc, c) => {
      const region = getRegion(c.country);
      if (!acc[region]) acc[region] = [];
      acc[region].push(c);
      return acc;
    }, {});

  const intlGroup = filtered.filter((c) => c.country !== "India");

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setQuery("");
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const selected = CITIES.find((c) => c.name === value);

  const handleSelect = (city: City) => {
    onChange(city.name);
    setOpen(false);
    setQuery("");
  };

  return (
    <div className="flex flex-col gap-1 relative" ref={ref}>
      {label && (
        <label className="text-xs text-[var(--muted-foreground)] font-medium uppercase tracking-wide">{label}</label>
      )}
      <button
        type="button"
        onClick={() => {
          setOpen((o) => !o);
          setTimeout(() => inputRef.current?.focus(), 50);
        }}
        className="w-full flex items-center gap-2 pl-3 pr-4 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm font-medium hover:border-[#4f6ef7] transition-colors text-left focus:outline-none"
      >
        <MapPin size={15} className="text-[#4f6ef7] shrink-0" />
        <span className="flex-1 truncate">{value || placeholder}</span>
        {selected && (
          <span className="font-mono text-xs text-[var(--muted-foreground)] bg-[var(--background)]/60 px-1.5 py-0.5 rounded shrink-0">
            {selected.code}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute top-full left-0 right-0 mt-1 z-[100] glass border border-[var(--border)] rounded-2xl shadow-2xl shadow-black/40 overflow-hidden">
          <div className="p-3 border-b border-[var(--border)]">
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search city, country or code..."
                className="w-full pl-9 pr-8 py-2 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-sm text-[var(--foreground)] focus:outline-none focus:border-[#4f6ef7]"
              />
              {query && (
                <button
                  onClick={() => setQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
                >
                  <X size={13} />
                </button>
              )}
            </div>
          </div>

          <div className="max-h-64 overflow-y-auto">
            {filtered.length === 0 && (
              <div className="py-8 text-center text-sm text-[var(--muted-foreground)]">No cities found</div>
            )}

            {indiaGroup.length > 0 && (
              <>
                <div className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-[var(--muted-foreground)] bg-[var(--muted)]/50 sticky top-0">
                  🇮🇳 India
                </div>
                {indiaGroup.map((c) => (
                  <button
                    key={c.code}
                    onClick={() => handleSelect(c)}
                    className={`w-full flex items-center justify-between px-4 py-2.5 text-sm hover:bg-[#4f6ef7]/10 transition-colors text-left ${value === c.name ? "text-[#4f6ef7] font-semibold bg-[#4f6ef7]/5" : "text-[var(--foreground)]"}`}
                  >
                    <div className="flex items-center gap-2">
                      <MapPin size={13} className={value === c.name ? "text-[#4f6ef7]" : "text-[var(--muted-foreground)]"} />
                      <span>{c.name}</span>
                    </div>
                    <span className="font-mono text-xs text-[var(--muted-foreground)]">{c.code}</span>
                  </button>
                ))}
              </>
            )}

            {intlGroup.length > 0 && Object.entries(intlByRegion).map(([region, cities]) => (
              <div key={region}>
                <div className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-[var(--muted-foreground)] bg-[var(--muted)]/50 sticky top-0">
                  🌍 {region}
                </div>
                {cities.map((c) => (
                  <button
                    key={c.code + c.name}
                    onClick={() => handleSelect(c)}
                    className={`w-full flex items-center justify-between px-4 py-2.5 text-sm hover:bg-[#4f6ef7]/10 transition-colors text-left ${value === c.name ? "text-[#4f6ef7] font-semibold bg-[#4f6ef7]/5" : "text-[var(--foreground)]"}`}
                  >
                    <div className="flex items-center gap-2">
                      <MapPin size={13} className={value === c.name ? "text-[#4f6ef7]" : "text-[var(--muted-foreground)]"} />
                      <div>
                        <span>{c.name}</span>
                        <span className="text-[var(--muted-foreground)] text-xs ml-1.5">{c.country}</span>
                      </div>
                    </div>
                    <span className="font-mono text-xs text-[var(--muted-foreground)]">{c.code}</span>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
