import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, Sun, Moon, User, LogOut } from "lucide-react";

interface HeaderProps {
  darkMode: boolean;
  toggleDark: () => void;
}

export default function Header({ darkMode, toggleDark }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const isAdmin = location.pathname.startsWith("/admin");

  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/search/bus", label: "Bus" },
    { to: "/search/train", label: "Train" },
    { to: "/search/flight", label: "Flight" },
    { to: "/smart-journey", label: "Smart Journey" },
    { to: "/dashboard", label: "My Bookings" },
  ];

  const active = (to: string) =>
    location.pathname === to ? "text-[#4f6ef7]" : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]";

  if (isAdmin) return null;

  return (
    <header className="sticky top-0 z-50 glass border-b border-[var(--border)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 select-none">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4f6ef7] to-[#00d4aa] flex items-center justify-center">
            <span className="text-white font-bold text-sm font-display">G</span>
          </div>
          <span className="font-display font-bold text-lg tracking-tight">GoVeya</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((l) => (
            <Link key={l.to} to={l.to} className={`text-sm font-medium transition-colors ${active(l.to)}`}>
              {l.label}
            </Link>
          ))}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleDark}
            className="w-9 h-9 rounded-full glass flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
          >
            {darkMode ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <Link
            to="/login"
            className="hidden sm:flex items-center gap-2 text-sm font-medium text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
          >
            <User size={16} />
            Login
          </Link>
          <Link
            to="/signup"
            className="hidden sm:block px-4 py-2 rounded-lg bg-[#4f6ef7] text-white text-sm font-semibold hover:bg-[#3b5bdb]"
          >
            Sign Up
          </Link>
          <button
            className="md:hidden w-9 h-9 rounded-full glass flex items-center justify-center"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden border-t border-[var(--border)] glass">
          <nav className="flex flex-col px-4 py-4 gap-3">
            {navLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className={`text-sm font-medium py-2 ${active(l.to)}`}
                onClick={() => setMenuOpen(false)}
              >
                {l.label}
              </Link>
            ))}
            <div className="flex gap-3 pt-2 border-t border-[var(--border)]">
              <Link to="/login" className="flex-1 text-center py-2 rounded-lg glass text-sm font-medium" onClick={() => setMenuOpen(false)}>Login</Link>
              <Link to="/signup" className="flex-1 text-center py-2 rounded-lg bg-[#4f6ef7] text-white text-sm font-semibold" onClick={() => setMenuOpen(false)}>Sign Up</Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
