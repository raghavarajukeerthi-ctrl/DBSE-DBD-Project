import { useEffect, useState } from "react";

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [phase, setPhase] = useState<"in" | "hold" | "out">("in");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("hold"), 100);
    const t2 = setTimeout(() => setPhase("out"), 2600);
    const t3 = setTimeout(() => onComplete(), 3400);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onComplete]);

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center overflow-hidden"
      style={{
        background: "#06080f",
        opacity: phase === "out" ? 0 : 1,
        transition: phase === "out" ? "opacity 0.8s cubic-bezier(0.4,0,0.2,1)" : "none",
        pointerEvents: phase === "out" ? "none" : "all",
      }}
    >
      {/* Ambient background pulses */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute rounded-full"
          style={{
            width: 600, height: 600,
            left: "50%", top: "50%",
            transform: "translate(-50%, -50%)",
            background: "radial-gradient(circle, rgba(79,110,247,0.18) 0%, transparent 70%)",
            opacity: phase === "in" ? 0 : 1,
            transition: "opacity 1.2s ease",
          }}
        />
        <div
          className="absolute rounded-full"
          style={{
            width: 900, height: 900,
            left: "50%", top: "50%",
            transform: "translate(-50%, -50%)",
            background: "radial-gradient(circle, rgba(0,212,170,0.08) 0%, transparent 65%)",
            opacity: phase === "in" ? 0 : 1,
            transition: "opacity 1.4s ease 0.2s",
          }}
        />
      </div>

      {/* Orbiting ring */}
      <div
        className="absolute rounded-full border border-[#4f6ef7]/20"
        style={{
          width: 260, height: 260,
          left: "50%", top: "50%",
          transform: "translate(-50%, -50%)",
          opacity: phase === "in" ? 0 : 0.6,
          transition: "opacity 1s ease 0.5s",
          animation: phase !== "in" ? "spin 8s linear infinite" : "none",
        }}
      />
      <div
        className="absolute rounded-full border border-[#00d4aa]/15"
        style={{
          width: 360, height: 360,
          left: "50%", top: "50%",
          transform: "translate(-50%, -50%)",
          opacity: phase === "in" ? 0 : 0.5,
          transition: "opacity 1s ease 0.7s",
          animation: phase !== "in" ? "spin-reverse 12s linear infinite" : "none",
        }}
      />

      {/* Dot on inner ring */}
      <div
        className="absolute"
        style={{
          width: 260, height: 260,
          left: "50%", top: "50%",
          transform: "translate(-50%, -50%)",
          animation: phase !== "in" ? "spin 8s linear infinite" : "none",
          opacity: phase === "in" ? 0 : 1,
          transition: "opacity 0.8s ease 0.6s",
        }}
      >
        <div
          className="absolute w-2.5 h-2.5 rounded-full bg-[#4f6ef7]"
          style={{ top: -5, left: "50%", transform: "translateX(-50%)", boxShadow: "0 0 12px #4f6ef7" }}
        />
      </div>
      {/* Dot on outer ring */}
      <div
        className="absolute"
        style={{
          width: 360, height: 360,
          left: "50%", top: "50%",
          transform: "translate(-50%, -50%)",
          animation: phase !== "in" ? "spin-reverse 12s linear infinite" : "none",
          opacity: phase === "in" ? 0 : 1,
          transition: "opacity 0.8s ease 0.8s",
        }}
      >
        <div
          className="absolute w-2 h-2 rounded-full bg-[#00d4aa]"
          style={{ bottom: -4, left: "50%", transform: "translateX(-50%)", boxShadow: "0 0 10px #00d4aa" }}
        />
      </div>

      {/* Center logo + wordmark */}
      <div className="relative flex flex-col items-center gap-5 z-10">
        {/* Logo mark */}
        <div
          style={{
            opacity: phase === "in" ? 0 : 1,
            transform: phase === "in" ? "scale(0.5) rotate(-20deg)" : "scale(1) rotate(0deg)",
            transition: "opacity 0.7s cubic-bezier(0.34,1.56,0.64,1), transform 0.7s cubic-bezier(0.34,1.56,0.64,1)",
          }}
        >
          <div
            className="w-20 h-20 rounded-3xl flex items-center justify-center relative"
            style={{
              background: "linear-gradient(135deg, #4f6ef7 0%, #00d4aa 100%)",
              boxShadow: "0 0 40px rgba(79,110,247,0.5), 0 0 80px rgba(0,212,170,0.2)",
            }}
          >
            {/* G letterform */}
            <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
              <path
                d="M36 22C36 29.732 29.732 36 22 36C14.268 36 8 29.732 8 22C8 14.268 14.268 8 22 8C27.2 8 31.76 10.8 34.2 15"
                stroke="white" strokeWidth="3.5" strokeLinecap="round" fill="none"
              />
              <path d="M27 22H36V30" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
            </svg>

            {/* Corner sparkles */}
            {[["-top-1.5", "-right-1.5"], ["-bottom-1.5", "-left-1.5"]].map(([t, l], i) => (
              <div
                key={i}
                className={`absolute ${t} ${l} w-3 h-3`}
                style={{ opacity: phase === "in" ? 0 : 1, transition: `opacity 0.5s ease ${0.9 + i * 0.15}s` }}
              >
                <svg viewBox="0 0 12 12" fill="none">
                  <path d="M6 0L7 5L12 6L7 7L6 12L5 7L0 6L5 5Z" fill={i === 0 ? "#4f6ef7" : "#00d4aa"} />
                </svg>
              </div>
            ))}
          </div>
        </div>

        {/* Wordmark: G o V e y a letter-by-letter */}
        <div className="flex items-baseline gap-0 overflow-hidden" style={{ fontFamily: "'DM Sans', sans-serif" }}>
          {"GoVeya".split("").map((char, i) => (
            <span
              key={i}
              style={{
                fontSize: 52,
                fontWeight: 900,
                letterSpacing: "-0.02em",
                lineHeight: 1,
                display: "inline-block",
                color: i < 2 ? "#e8eaf2" : i === 2 ? "#4f6ef7" : i < 5 ? "#e8eaf2" : "#00d4aa",
                opacity: phase === "in" ? 0 : 1,
                transform: phase === "in" ? "translateY(30px)" : "translateY(0)",
                transition: `opacity 0.5s ease ${0.3 + i * 0.06}s, transform 0.6s cubic-bezier(0.34,1.3,0.64,1) ${0.3 + i * 0.06}s`,
              }}
            >
              {char}
            </span>
          ))}
        </div>

        {/* Tagline */}
        <div
          style={{
            opacity: phase === "in" ? 0 : 1,
            transform: phase === "in" ? "translateY(10px)" : "translateY(0)",
            transition: "opacity 0.6s ease 0.85s, transform 0.6s ease 0.85s",
            display: "flex",
            alignItems: "center",
            gap: 12,
          }}
        >
          <div style={{ height: 1, width: 40, background: "linear-gradient(to right, transparent, #4f6ef7)" }} />
          <span style={{ fontSize: 13, fontWeight: 500, letterSpacing: "0.18em", color: "#6b7280", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
            One Journey. Every Way.
          </span>
          <div style={{ height: 1, width: 40, background: "linear-gradient(to left, transparent, #00d4aa)" }} />
        </div>

        {/* Loading bar */}
        <div
          style={{
            opacity: phase === "in" ? 0 : 1,
            transition: "opacity 0.4s ease 1s",
            width: 160,
            marginTop: 12,
          }}
        >
          <div style={{ height: 2, borderRadius: 99, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
            <div
              style={{
                height: "100%",
                borderRadius: 99,
                background: "linear-gradient(to right, #4f6ef7, #00d4aa)",
                width: phase === "hold" ? "100%" : phase === "in" ? "0%" : "100%",
                transition: "width 1.8s cubic-bezier(0.4,0,0.2,1) 0.9s",
                boxShadow: "0 0 8px #4f6ef7",
              }}
            />
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spin { from { transform: translate(-50%,-50%) rotate(0deg); } to { transform: translate(-50%,-50%) rotate(360deg); } }
        @keyframes spin-reverse { from { transform: translate(-50%,-50%) rotate(0deg); } to { transform: translate(-50%,-50%) rotate(-360deg); } }
      `}</style>
    </div>
  );
}
