import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Calendar, Users, ArrowRight, ArrowLeftRight, Zap } from "lucide-react";
import LocationPicker from "./LocationPicker";

type Tab = "bus" | "train" | "flight" | "smart";

export default function SearchPanel({ defaultTab = "flight" }: { defaultTab?: Tab }) {
  const [tab, setTab] = useState<Tab>(defaultTab);
  const [from, setFrom] = useState("Hyderabad");
  const [to, setTo] = useState("Bengaluru");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [returnDate, setReturnDate] = useState("");
  const [passengers, setPassengers] = useState(1);
  const navigate = useNavigate();

  const swap = () => { const t = from; setFrom(to); setTo(t); };

  const handleSearch = () => {
    if (tab === "smart") { navigate("/smart-journey"); return; }
    navigate(`/search/${tab}?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${date}&passengers=${passengers}`);
  };

  const tabs: { id: Tab; label: string; icon: string }[] = [
    { id: "bus", label: "Bus", icon: "🚌" },
    { id: "train", label: "Train", icon: "🚆" },
    { id: "flight", label: "Flight", icon: "✈️" },
    { id: "smart", label: "Smart Journey", icon: "⚡" },
  ];

  return (
    <div className="glass rounded-2xl p-6 w-full max-w-4xl mx-auto">
      {/* Tabs */}
      <div className="flex gap-1 mb-6 bg-[var(--muted)] rounded-xl p-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all ${
              tab === t.id
                ? "bg-[#4f6ef7] text-white shadow-lg"
                : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
            }`}
          >
            <span>{t.icon}</span>
            <span className="hidden sm:inline">{t.label}</span>
          </button>
        ))}
      </div>

      {tab === "smart" ? (
        <div className="flex flex-col items-center gap-4 py-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#4f6ef7] to-[#00d4aa] flex items-center justify-center">
            <Zap size={32} className="text-white" />
          </div>
          <div className="text-center">
            <h3 className="font-display font-bold text-xl mb-1">GoVeya Smart Journey</h3>
            <p className="text-[var(--muted-foreground)] text-sm">Compare complete multi-modal journeys with risk analysis</p>
          </div>
          <button
            onClick={handleSearch}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-[#4f6ef7] to-[#00d4aa] text-white font-bold text-sm hover:opacity-90"
          >
            Plan Smart Journey →
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-3 items-end">
            <LocationPicker label="From" value={from} onChange={setFrom} exclude={to} />
            <button
              onClick={swap}
              className="mb-0.5 w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-[#4f6ef7] hover:text-white mx-auto transition-colors"
            >
              <ArrowLeftRight size={16} />
            </button>
            <LocationPicker label="To" value={to} onChange={setTo} exclude={from} />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs text-[var(--muted-foreground)] font-medium uppercase tracking-wide">Departure</label>
              <div className="relative">
                <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm font-medium focus:outline-none focus:border-[#4f6ef7]"
                />
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs text-[var(--muted-foreground)] font-medium uppercase tracking-wide">Return (optional)</label>
              <div className="relative">
                <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                <input
                  type="date"
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm font-medium focus:outline-none focus:border-[#4f6ef7]"
                />
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs text-[var(--muted-foreground)] font-medium uppercase tracking-wide">Passengers</label>
              <div className="relative">
                <Users size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
                <select
                  value={passengers}
                  onChange={(e) => setPassengers(Number(e.target.value))}
                  className="w-full pl-9 pr-3 py-3 rounded-xl bg-[var(--muted)] border border-[var(--border)] text-[var(--foreground)] text-sm font-medium focus:outline-none focus:border-[#4f6ef7]"
                >
                  {[1,2,3,4,5,6].map((n) => <option key={n} value={n}>{n} Passenger{n > 1 ? "s" : ""}</option>)}
                </select>
              </div>
            </div>
          </div>

          <button
            onClick={handleSearch}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-[#4f6ef7] to-[#3b5bdb] text-white font-bold text-base hover:opacity-90 flex items-center justify-center gap-2 pulse-glow"
          >
            Search Tickets <ArrowRight size={18} />
          </button>
        </div>
      )}
    </div>
  );
}
