import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";

interface LandingGateProps {
  onEnter: () => void;
}

export default function LandingGate({ onEnter }: LandingGateProps) {
  const [leaving, setLeaving] = useState(false);
  const navigate = useNavigate();

  const handleEnter = () => {
    setLeaving(true);
    setTimeout(() => {
      onEnter();
      navigate("/");
    }, 700);
  };

  return (
    <div
      className="fixed inset-0 z-[9998] flex flex-col items-center justify-center hero-gradient overflow-hidden"
      style={{
        opacity: leaving ? 0 : 1,
        transform: leaving ? "scale(1.04)" : "scale(1)",
        transition: "opacity 0.7s cubic-bezier(0.4,0,0.2,1), transform 0.7s cubic-bezier(0.4,0,0.2,1)",
      }}
    >
      {/* Ambient orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(79,110,247,0.12) 0%, transparent 70%)", filter: "blur(40px)" }} />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(0,212,170,0.10) 0%, transparent 70%)", filter: "blur(40px)" }} />

      {/* Subtle grid */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{ backgroundImage: "linear-gradient(#4f6ef7 1px, transparent 1px), linear-gradient(90deg, #4f6ef7 1px, transparent 1px)", backgroundSize: "60px 60px" }} />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center gap-7 px-4 text-center">

        {/* Logo mark */}
        <div
          className="w-24 h-24 rounded-3xl flex items-center justify-center"
          style={{
            background: "linear-gradient(135deg, #4f6ef7 0%, #00d4aa 100%)",
            boxShadow: "0 0 60px rgba(79,110,247,0.45), 0 0 120px rgba(0,212,170,0.15)",
            animation: "float 4s ease-in-out infinite",
          }}
        >
          <svg width="52" height="52" viewBox="0 0 44 44" fill="none">
            <path d="M36 22C36 29.732 29.732 36 22 36C14.268 36 8 29.732 8 22C8 14.268 14.268 8 22 8C27.2 8 31.76 10.8 34.2 15"
              stroke="white" strokeWidth="3.5" strokeLinecap="round" fill="none"/>
            <path d="M27 22H36V30" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
          </svg>
        </div>

        {/* Wordmark */}
        <div>
          <div className="font-display font-black leading-none mb-2" style={{ fontSize: "clamp(48px, 10vw, 88px)", letterSpacing: "-0.03em" }}>
            <span style={{ color: "#e8eaf2" }}>Go</span>
            <span style={{ color: "#4f6ef7" }}>V</span>
            <span style={{ color: "#e8eaf2" }}>ey</span>
            <span style={{ color: "#00d4aa" }}>a</span>
          </div>
          <p className="text-[var(--muted-foreground)] text-sm sm:text-base font-medium uppercase" style={{ letterSpacing: "0.2em" }}>
            One Journey. Every Way.
          </p>
        </div>

        {/* Start Booking CTA */}
        <button
          onClick={handleEnter}
          className="group relative flex items-center gap-3 px-10 py-4 rounded-2xl font-display font-bold text-lg text-white overflow-hidden"
          style={{
            background: "linear-gradient(135deg, #4f6ef7, #3b5bdb, #00d4aa)",
            backgroundSize: "200% 200%",
            boxShadow: "0 0 30px rgba(79,110,247,0.4), 0 4px 24px rgba(0,0,0,0.3)",
            animation: "gradient-shift 3s ease infinite, pulse-glow 2s ease-in-out infinite",
          }}
        >
          <span>Start Booking</span>
          <ArrowRight size={20} className="transition-transform duration-300 group-hover:translate-x-1" />
          <div className="absolute inset-0 pointer-events-none"
            style={{ background: "linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.18) 50%, transparent 60%)", backgroundSize: "200% 100%", animation: "shimmer-sweep 2.5s ease infinite" }} />
        </button>
      </div>

      <style>{`
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }
        @keyframes gradient-shift { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        @keyframes shimmer-sweep { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
      `}</style>
    </div>
  );
}
